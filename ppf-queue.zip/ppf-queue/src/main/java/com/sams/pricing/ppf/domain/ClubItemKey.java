package com.sams.pricing.ppf.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ClubItemKey implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name="CLUB_NBR",nullable=false)
	private int clubNbr;
	
	public int getClubNbr() {
		return clubNbr;
	}

	public void setClubNbr(int clubNbr) {
		this.clubNbr = clubNbr;
	}

	public int getItemNbr() {
		return itemNbr;
	}

	public void setItemNbr(int itemNbr) {
		this.itemNbr = itemNbr;
	}

	@Column(name="ITEM_NBR",nullable=false)
	private int itemNbr;
}
