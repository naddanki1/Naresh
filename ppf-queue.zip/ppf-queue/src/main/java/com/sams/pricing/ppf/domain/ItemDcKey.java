package com.sams.pricing.ppf.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class ItemDcKey implements Serializable 
{

	private static final long serialVersionUID = 1L;
	
	Integer itemNbr ;
	Integer dcNbr ;
	
	public Integer getItemNbr() {
		return itemNbr;
	}
	public void setItemNbr(Integer itemNbr) {
		this.itemNbr = itemNbr;
	}
	public Integer getDcNbr() {
		return dcNbr;
	}
	public void setDcNbr(Integer dcNbr) {
		this.dcNbr = dcNbr;
	}
}
