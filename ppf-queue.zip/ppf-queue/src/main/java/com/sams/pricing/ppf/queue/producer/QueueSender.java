package com.sams.pricing.ppf.queue.producer;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.azure.servicebus.IMessage;
import com.microsoft.azure.servicebus.IMessageSender;
import com.microsoft.azure.servicebus.Message;
import com.sams.pricing.ppf.model.QueueStats;
import com.sams.pricing.ppf.util.GenericRawTableObject;

@Component
public class QueueSender {
	static final Gson GSON = new Gson();

	@Value("${ConnectionString}")
	private String connectionString;

	@Value("${queue.name}")
	private String queueName;

	private int durationToLiveInMinutes = 2;
	private static final Logger logger = LoggerFactory.getLogger(QueueSender.class);
	private final int connectionTimeoutInSeconds = 60;

	public int getDurationToLive() {
		return durationToLiveInMinutes;
	}

	public void setDurationToLive(int durationToLive) {
		this.durationToLiveInMinutes = durationToLive;
	}

	public QueueSender() {

	}

	/**
	 * This is just a test method for checking synchronously sending messages.
	 * 
	 * @param cachedSender
	 * @param queueStats
	 * @param message
	 */
	private void sendMessageSync(IMessageSender cachedSender, QueueStats queueStats, Message message) {
		try {
			cachedSender.send(message);
			logger.debug("SUCCESS: message sent "
					+ ((queueStats.getQueueNumber() + 1) * (Integer.parseInt(message.getMessageId()) + 1)));
			queueStats.incSuccessCount();

		} catch (Exception e) {
			logger.debug("FAILED at sendSync(): sendMessages" + message.getMessageId());
			queueStats.incFailedCount();
			queueStats.setFailedIndex(message.getMessageId());
			e.printStackTrace();
		}
	}

	/**
	 * Each message is being set asynchronously and queue statistics are updated.
	 * We've problem while updating the success and failed counts.
	 * 
	 * @param cachedSender
	 * @param queueStats
	 * @param message
	 * @return
	 */
	private CompletableFuture<Void> sendMessageAsync(IMessageSender cachedSender, QueueStats queueStats,
			IMessage message) {
		CompletableFuture<Void> future = null;

		future = cachedSender.sendAsync(message).whenCompleteAsync((result, exception) -> {
			if (exception == null) {
				queueStats.incSuccessCount();
			} else {
				logger.debug("FAILED: sendMessages" + message.getMessageId());
				queueStats.incFailedCount();
				queueStats.setFailedIndex(message.getMessageId());

			}
		});

		return future;
	}

	/**
	 * Convert the list of messages to azure IMessage's and post each message
	 * Asynchronously to service bus.
	 * 
	 * @param cachedSender
	 * @param itemsList
	 * @param tableName
	 * @param queueStats
	 * @return
	 * @throws JsonProcessingException
	 * @throws ExecutionException
	 * @throws InterruptedException
	 */
	public void sendMessages(IMessageSender cachedSender, List<Object> itemsList, String tableName,
			QueueStats queueStats) throws InterruptedException, ExecutionException, JsonProcessingException {

		List<CompletableFuture<Void>> futureList = new ArrayList<CompletableFuture<Void>>();

		for (int i = 0; i < itemsList.size(); ++i) {

			ObjectMapper objectMapper = new ObjectMapper();

			GenericRawTableObject jsonMessage = new GenericRawTableObject();
			Message message = new Message();

			jsonMessage.setTableName(tableName);

			jsonMessage.setJsonObject(itemsList.get(i));

			int msgID = (i + 1) * (queueStats.getQueueNumber() + 1);
			final String messageId = Integer.toString(msgID);

			message.setBody(objectMapper.writeValueAsString(jsonMessage).getBytes());

			message.setContentType("application/json");

			message.setLabel(tableName + "-" + queueStats.getQueueNumber());

			message.setMessageId(messageId);

			message.setTimeToLive(Duration.ofMinutes(durationToLiveInMinutes));

			CompletableFuture<Void> future = sendMessageAsync(cachedSender, queueStats, message);
			// Add each async message which is sent.
			futureList.add(future);
		}

		// Wait on the sub-thread till all of them are finished.
		logger.debug("Waiting on Queue " + queueStats.getQueueNumber());
		CompletableFuture.allOf(futureList.toArray(new CompletableFuture<?>[futureList.size()])).thenAcceptAsync(s -> {
			logger.debug("Finished Queue" + queueStats.getQueueNumber());

		}).get();

	}

}