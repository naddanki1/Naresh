package com.sams.pricing.ppf.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "CLUB_ITEM", schema = "T7SAMITM")
//@IdClass(value = ClubItemKey.class)
public class ClubItem {

	@EmbeddedId
	private ClubItemKey clubItemKey;

	public ClubItemKey getClubItemKey() {
		return clubItemKey;
	}

	public void setClubItemKey(ClubItemKey clubItemKey) {
		this.clubItemKey = clubItemKey;
	}

	private String itemOnShelfDate;
	private Integer markdownStatusCd = new Integer(1);
	private String itemStatusCode;
	private Float unitRetailAmt;
	private Integer linkItemNbr;
	private Date lastChangeTs;
	private String lastChangeUserid;
	private String nonMbrUpchrgInd;
	private String unitRetailChgDt;
	private String lastMarkdownInd;
	private Float whpkSellAmt;
	private Float vnpkCostAmt;
	private String lastUpdatePgmId;
	private String itemCreateDt;
	private String cancelWhnOutDt;
	@Column(nullable = true)
	private Float cnclUnitRtlAmt;
	private Integer leadTimeQty;
	private String promptPriceInd;
	private Float leaseSalesPct;
	private String leaseEffDate;
	private String leaseExpDate;
	private String lastSoldDate;
	private Float leaseDfltSlsPct;
	private String itemfileSourceNm;
	private Float maxRetailAmt;
	private Integer whpkSellChgRsnCd;
	private Timestamp sysStartTm;

	public String getItemOnShelfDate() {
		return itemOnShelfDate;
	}

	public void setItemOnShelfDate(String itemOnShelfDate) {
		this.itemOnShelfDate = itemOnShelfDate;
	}

	public Integer getMarkdownStatusCd() {
		return markdownStatusCd;
	}

	public void setMarkdownStatusCd(Integer markdownStatusCd) {
		this.markdownStatusCd = markdownStatusCd;
	}

	public String getItemStatusCode() {
		return itemStatusCode;
	}

	public void setItemStatusCode(String itemStatusCode) {
		this.itemStatusCode = itemStatusCode;
	}

	public Float getUnitRetailAmt() {
		return unitRetailAmt;
	}

	public void setUnitRetailAmt(Float unitRetailAmt) {
		this.unitRetailAmt = unitRetailAmt;
	}

	public Integer getLinkItemNbr() {
		return linkItemNbr;
	}

	public void setLinkItemNbr(Integer linkItemNbr) {
		this.linkItemNbr = linkItemNbr;
	}

	public Date getLastChangeTs() {
		return lastChangeTs;
	}

	public void setLastChangeTs(Date lastChangeTs) {
		this.lastChangeTs = lastChangeTs;
	}

	public String getLastChangeUserid() {
		return lastChangeUserid;
	}

	public void setLastChangeUserid(String lastChangeUserid) {
		this.lastChangeUserid = lastChangeUserid;
	}

	public String getNonMbrUpchrgInd() {
		return nonMbrUpchrgInd;
	}

	public void setNonMbrUpchrgInd(String nonMbrUpchrgInd) {
		this.nonMbrUpchrgInd = nonMbrUpchrgInd;
	}

	public String getUnitRetailChgDt() {
		return unitRetailChgDt;
	}

	public void setUnitRetailChgDt(String unitRetailChgDt) {
		this.unitRetailChgDt = unitRetailChgDt;
	}

	public String getLastMarkdownInd() {
		return lastMarkdownInd;
	}

	public void setLastMarkdownInd(String lastMarkdownInd) {
		this.lastMarkdownInd = lastMarkdownInd;
	}

	public Float getWhpkSellAmt() {
		return whpkSellAmt;
	}

	public void setWhpkSellAmt(Float whpkSellAmt) {
		this.whpkSellAmt = whpkSellAmt;
	}

	public Float getVnpkCostAmt() {
		return vnpkCostAmt;
	}

	public void setVnpkCostAmt(Float vnpkCostAmt) {
		this.vnpkCostAmt = vnpkCostAmt;
	}

	public String getLastUpdatePgmId() {
		return lastUpdatePgmId;
	}

	public void setLastUpdatePgmId(String lastUpdatePgmId) {
		this.lastUpdatePgmId = lastUpdatePgmId;
	}

	public String getItemCreateDt() {
		return itemCreateDt;
	}

	public void setItemCreateDt(String itemCreateDt) {
		this.itemCreateDt = itemCreateDt;
	}

	public String getCancelWhnOutDt() {
		return cancelWhnOutDt;
	}

	public void setCancelWhnOutDt(String cancelWhnOutDt) {
		this.cancelWhnOutDt = cancelWhnOutDt;
	}

	public Float getCnclUnitRtlAmt() {
		return cnclUnitRtlAmt;
	}

	public void setCnclUnitRtlAmt(Float cnclUnitRtlAmt) {
		this.cnclUnitRtlAmt = cnclUnitRtlAmt;
	}

	public Integer getLeadTimeQty() {
		return leadTimeQty;
	}

	public void setLeadTimeQty(Integer leadTimeQty) {
		this.leadTimeQty = leadTimeQty;
	}

	public String getPromptPriceInd() {
		return promptPriceInd;
	}

	public void setPromptPriceInd(String promptPriceInd) {
		this.promptPriceInd = promptPriceInd;
	}

	public Float getLeaseSalesPct() {
		return leaseSalesPct;
	}

	public void setLeaseSalesPct(Float leaseSalesPct) {
		this.leaseSalesPct = leaseSalesPct;
	}

	public String getLeaseEffDate() {
		return leaseEffDate;
	}

	public void setLeaseEffDate(String leaseEffDate) {
		this.leaseEffDate = leaseEffDate;
	}

	public String getLeaseExpDate() {
		return leaseExpDate;
	}

	public void setLeaseExpDate(String leaseExpDate) {
		this.leaseExpDate = leaseExpDate;
	}

	public String getLastSoldDate() {
		return lastSoldDate;
	}

	public void setLastSoldDate(String lastSoldDate) {
		this.lastSoldDate = lastSoldDate;
	}

	public Float getLeaseDfltSlsPct() {
		return leaseDfltSlsPct;
	}

	public void setLeaseDfltSlsPct(Float leaseDfltSlsPct) {
		this.leaseDfltSlsPct = leaseDfltSlsPct;
	}

	public String getItemfileSourceNm() {
		return itemfileSourceNm;
	}

	public void setItemfileSourceNm(String itemfileSourceNm) {
		this.itemfileSourceNm = itemfileSourceNm;
	}

	public Float getMaxRetailAmt() {
		return maxRetailAmt;
	}

	public void setMaxRetailAmt(Float maxRetailAmt) {
		this.maxRetailAmt = maxRetailAmt;
	}

	public Integer getWhpkSellChgRsnCd() {
		return whpkSellChgRsnCd;
	}

	public void setWhpkSellChgRsnCd(Integer whpkSellChgRsnCd) {
		this.whpkSellChgRsnCd = whpkSellChgRsnCd;
	}

	public Timestamp getSysStartTm() {
		return sysStartTm;
	}

	public void setSysStartTm(Timestamp sysStartTm) {
		this.sysStartTm = sysStartTm;
	}
}
