package com.sams.pricing.ppf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableAutoConfiguration
//@ComponentScan({ "com.sams.pricing.ppf.service", "com.sams.pricing.ppf.repository", "com.sams.pricing.ppf.domain",
//		"com.sams.pricing.ppf.controller.*", "com.sams.pricing.ppf.queue.producer" })
@ComponentScan({ "com.sams.pricing.ppf.*" })
@EnableJpaRepositories("com.sams.pricing.ppf.repository")
public class QueueProducerApplication {
	public static void main(String[] args) {
		SpringApplication.run(QueueProducerApplication.class, args);
	}

}
