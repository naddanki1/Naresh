package com.sams.pricing.ppf.queue.producer;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.microsoft.azure.servicebus.ClientFactory;
import com.microsoft.azure.servicebus.IMessageSender;
import com.microsoft.azure.servicebus.primitives.ConnectionStringBuilder;
import com.microsoft.azure.servicebus.primitives.RetryPolicy;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;

@Component
@PropertySource("classpath:application.properties")

public class QueueConnectionsHandler {
	private List<IMessageSender> sendersList = null;
	private static final Logger logger = LoggerFactory.getLogger(QueueSender.class);
	Queue<Integer> connectionsTracker = new LinkedList<>();
	final ConnectionStringBuilder connectionStringBuilder;
	final int connectionTimeoutInSeconds = 60;

	@Autowired
	public QueueConnectionsHandler(@Value("${ConnectionString}") String connectionString,
			@Value("${queue.name}") String queueName) {
		connectionStringBuilder = new ConnectionStringBuilder(connectionString, queueName);
		// We're not setting the retry as we're manually doing it.
		connectionStringBuilder.setRetryPolicy(RetryPolicy.getDefault());
		connectionStringBuilder.setOperationTimeout(Duration.ofSeconds(connectionTimeoutInSeconds));
	}

	public void createConnections(int maxConnectionsToQueue)
			throws InterruptedException, ExecutionException, ServiceBusException {
		Instant start = Instant.now();
		sendersList = new ArrayList<>();

		for (int i = 0; i < maxConnectionsToQueue; ++i) {
			final int connectionsIndex = i;
			IMessageSender messageSender = ClientFactory
					.createMessageSenderFromConnectionStringBuilder(connectionStringBuilder);
			connectionsTracker.add(connectionsIndex);
			sendersList.add(messageSender);
			logger.debug("Established Connection" + connectionsIndex);
		}
		Instant end = Instant.now();
		Duration timeElapsed = Duration.between(start, end);
		logger.debug("Total time: to create connections " + timeElapsed.getSeconds() + " seconds");
		logger.debug("Successfully created " + sendersList.size() + "connections");
	}

	/**
	 * Established a new connection to service bus every time and returns it. You
	 * can reuse the same connection once messages sending is done. There is no need
	 * to recreate it everytime after sending a message or batch of them.
	 * 
	 * @return messageSender
	 */

	public void closeConnectionsAsync() throws InterruptedException, ExecutionException {
		List<CompletableFuture<Void>> connectionsFuture = new ArrayList<>();
		while (!connectionsTracker.isEmpty())
			connectionsTracker.poll();

		for (IMessageSender sender : sendersList) {
			connectionsFuture.add(sender.closeAsync());
		}
		sendersList = null;
		CompletableFuture.allOf(connectionsFuture.toArray(new CompletableFuture<?>[connectionsFuture.size()]))
				.thenAcceptAsync(s -> {
				}).get();
		logger.debug("Closed connections");

	}

	public IMessageSender getMessageSender(int messageSenderIndex) {

		return sendersList.get(messageSenderIndex);
	}

	public int getFreeMessageSenderConnectionIndex() {
		if (connectionsTracker.isEmpty())
			return -1;
		
		return connectionsTracker.poll();
	}

	public void freeMessageSenderConnection(int index) {
		connectionsTracker.add(index);
	}
}
