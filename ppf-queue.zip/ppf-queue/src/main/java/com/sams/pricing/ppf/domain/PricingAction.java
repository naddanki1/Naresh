package com.sams.pricing.ppf.domain;

import java.sql.Timestamp;
import java.util.Date;

public class PricingAction 
{
	int pricingActionId;
	int priceTypeCode;
	int pricingReasonCd;
	Date effectiveDate;
	Date expirationDate;
	int costTypeCode;
	int itemSourceId;
	int itemSourceType;
	int priceDestId;
	int priceDestType;
	String uomCode;
	int pricingQty;
	int calcFormatCode;
	double calcValue;
	int priceActnStatCd;
	String lastChangeUserid;
	char maintMethodInd;
	Timestamp lastChangeTs;
	Timestamp processTs;
	String creatorId;
	double vnpkPpdCodtAmt;
	double vnpkColCostAmt;
	char buVnpkCostInd;
	int marginRuleId;
	int pricePointId;
	int ruleRestSeqNbr;
	Timestamp paCreateTs;
	String pricingSourceNm;
	char notifyStoreInd;
	double custBaseRtlAmt;
	String lastUpdatePgmId;
	double natlLsPriceAmt;
	double brktPriceAmt;
	int rtlRecCreateStatusCd;
	int linkedPricingActionId;
	Timestamp sysStartTm;
	public int getPricingActionId() {
		return pricingActionId;
	}
	public void setPricingActionId(int pricingActionId) {
		this.pricingActionId = pricingActionId;
	}
	public int getPriceTypeCode() {
		return priceTypeCode;
	}
	public void setPriceTypeCode(int priceTypeCode) {
		this.priceTypeCode = priceTypeCode;
	}
	public int getPricingReasonCd() {
		return pricingReasonCd;
	}
	public void setPricingReasonCd(int pricingReasonCd) {
		this.pricingReasonCd = pricingReasonCd;
	}
	public Date getEffectiveDate() {
		return effectiveDate;
	}
	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	public int getCostTypeCode() {
		return costTypeCode;
	}
	public void setCostTypeCode(int costTypeCode) {
		this.costTypeCode = costTypeCode;
	}
	public int getItemSourceId() {
		return itemSourceId;
	}
	public void setItemSourceId(int itemSourceId) {
		this.itemSourceId = itemSourceId;
	}
	public int getItemSourceType() {
		return itemSourceType;
	}
	public void setItemSourceType(int itemSourceType) {
		this.itemSourceType = itemSourceType;
	}
	public int getPriceDestId() {
		return priceDestId;
	}
	public void setPriceDestId(int priceDestId) {
		this.priceDestId = priceDestId;
	}
	public int getPriceDestType() {
		return priceDestType;
	}
	public void setPriceDestType(int priceDestType) {
		this.priceDestType = priceDestType;
	}
	public String getUomCode() {
		return uomCode;
	}
	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}
	public int getPricingQty() {
		return pricingQty;
	}
	public void setPricingQty(int pricingQty) {
		this.pricingQty = pricingQty;
	}
	public int getCalcFormatCode() {
		return calcFormatCode;
	}
	public void setCalcFormatCode(int calcFormatCode) {
		this.calcFormatCode = calcFormatCode;
	}
	public double getCalcValue() {
		return calcValue;
	}
	public void setCalcValue(double calcValue) {
		this.calcValue = calcValue;
	}
	public int getPriceActnStatCd() {
		return priceActnStatCd;
	}
	public void setPriceActnStatCd(int priceActnStatCd) {
		this.priceActnStatCd = priceActnStatCd;
	}
	public String getLastChangeUserid() {
		return lastChangeUserid;
	}
	public void setLastChangeUserid(String lastChangeUserid) {
		this.lastChangeUserid = lastChangeUserid;
	}
	public char getMaintMethodInd() {
		return maintMethodInd;
	}
	public void setMaintMethodInd(char maintMethodInd) {
		this.maintMethodInd = maintMethodInd;
	}
	public Timestamp getLastChangeTs() {
		return lastChangeTs;
	}
	public void setLastChangeTs(Timestamp lastChangeTs) {
		this.lastChangeTs = lastChangeTs;
	}
	public Timestamp getProcessTs() {
		return processTs;
	}
	public void setProcessTs(Timestamp processTs) {
		this.processTs = processTs;
	}
	public String getCreatorId() {
		return creatorId;
	}
	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}
	public double getVnpkPpdCodtAmt() {
		return vnpkPpdCodtAmt;
	}
	public void setVnpkPpdCodtAmt(double vnpkPpdCodtAmt) {
		this.vnpkPpdCodtAmt = vnpkPpdCodtAmt;
	}
	public double getVnpkColCostAmt() {
		return vnpkColCostAmt;
	}
	public void setVnpkColCostAmt(double vnpkColCostAmt) {
		this.vnpkColCostAmt = vnpkColCostAmt;
	}
	public char getBuVnpkCostInd() {
		return buVnpkCostInd;
	}
	public void setBuVnpkCostInd(char buVnpkCostInd) {
		this.buVnpkCostInd = buVnpkCostInd;
	}
	public int getMarginRuleId() {
		return marginRuleId;
	}
	public void setMarginRuleId(int marginRuleId) {
		this.marginRuleId = marginRuleId;
	}
	public int getPricePointId() {
		return pricePointId;
	}
	public void setPricePointId(int pricePointId) {
		this.pricePointId = pricePointId;
	}
	public int getRuleRestSeqNbr() {
		return ruleRestSeqNbr;
	}
	public void setRuleRestSeqNbr(int ruleRestSeqNbr) {
		this.ruleRestSeqNbr = ruleRestSeqNbr;
	}
	public Timestamp getPaCreateTs() {
		return paCreateTs;
	}
	public void setPaCreateTs(Timestamp paCreateTs) {
		this.paCreateTs = paCreateTs;
	}
	public String getPricingSourceNm() {
		return pricingSourceNm;
	}
	public void setPricingSourceNm(String pricingSourceNm) {
		this.pricingSourceNm = pricingSourceNm;
	}
	public char getNotifyStoreInd() {
		return notifyStoreInd;
	}
	public void setNotifyStoreInd(char notifyStoreInd) {
		this.notifyStoreInd = notifyStoreInd;
	}
	public double getCustBaseRtlAmt() {
		return custBaseRtlAmt;
	}
	public void setCustBaseRtlAmt(double custBaseRtlAmt) {
		this.custBaseRtlAmt = custBaseRtlAmt;
	}
	public String getLastUpdatePgmId() {
		return lastUpdatePgmId;
	}
	public void setLastUpdatePgmId(String lastUpdatePgmId) {
		this.lastUpdatePgmId = lastUpdatePgmId;
	}
	public double getNatlLsPriceAmt() {
		return natlLsPriceAmt;
	}
	public void setNatlLsPriceAmt(double natlLsPriceAmt) {
		this.natlLsPriceAmt = natlLsPriceAmt;
	}
	public double getBrktPriceAmt() {
		return brktPriceAmt;
	}
	public void setBrktPriceAmt(double brktPriceAmt) {
		this.brktPriceAmt = brktPriceAmt;
	}
	public int getRtlRecCreateStatusCd() {
		return rtlRecCreateStatusCd;
	}
	public void setRtlRecCreateStatusCd(int rtlRecCreateStatusCd) {
		this.rtlRecCreateStatusCd = rtlRecCreateStatusCd;
	}
	public int getLinkedPricingActionId() {
		return linkedPricingActionId;
	}
	public void setLinkedPricingActionId(int linkedPricingActionId) {
		this.linkedPricingActionId = linkedPricingActionId;
	}
	public Timestamp getSysStartTm() {
		return sysStartTm;
	}
	public void setSysStartTm(Timestamp sysStartTm) {
		this.sysStartTm = sysStartTm;
	}
}
