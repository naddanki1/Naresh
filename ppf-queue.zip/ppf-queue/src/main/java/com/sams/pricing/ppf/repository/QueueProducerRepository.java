package com.sams.pricing.ppf.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sams.pricing.ppf.domain.ClubItem;
import com.sams.pricing.ppf.domain.ClubItemKey;

@Repository
public interface QueueProducerRepository extends JpaRepository<ClubItem, ClubItemKey> {
	@Query("SELECT c FROM ClubItem c WHERE ITEM_NBR>=11997 AND ITEM_NBR<=12000")
	public List<Object> findBySysStartTm(@Param("sysStartTm") Date sysStartTm);

	@Query("SELECT c FROM ClubItem c WHERE ITEM_NBR>=?1 AND ITEM_NBR<=12000")
	public List<Object> findByItemRange(@Param("sysStartTm") int startRange);
}