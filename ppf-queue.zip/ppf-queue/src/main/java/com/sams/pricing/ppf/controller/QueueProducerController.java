package com.sams.pricing.ppf.controller;

import java.time.Duration;
import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sams.pricing.ppf.queue.producer.QueueSender;
import com.sams.pricing.ppf.service.QueueProducerService;

@RestController
public class QueueProducerController {
	@Autowired
	private QueueProducerService queueProducerService;

	private static final Logger logger = LoggerFactory.getLogger(QueueSender.class);

	@RequestMapping("/testSchedule")
	@GetMapping
	public String queueController(@RequestParam(value = "size", required = true) int batchSize,
			@RequestParam(value = "start", required = true) int startRange,
			@RequestParam(value = "ttl", required = true) int ttl) {
		Instant start = Instant.now();
		queueProducerService.fetchItemsAndSendMessages(batchSize, startRange, ttl);
		Instant end = Instant.now();
		Duration timeElapsed = Duration.between(start, end);
		logger.debug("Total time: " + timeElapsed.getSeconds() + " seconds \n\n");
		return "Time taken:  " + timeElapsed;
	}
}