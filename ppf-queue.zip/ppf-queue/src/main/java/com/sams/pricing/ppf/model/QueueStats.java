package com.sams.pricing.ppf.model;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sams.pricing.ppf.queue.producer.QueueSender;

public class QueueStats {
	private AtomicInteger successCount = new AtomicInteger(0);
	private AtomicInteger failedCount = new AtomicInteger(0);

	private int queueNumber;
	private int totalCount = 0;
	private Map<String, Integer> failedIndexes = new HashMap();
	private static final Logger logger = LoggerFactory.getLogger(QueueSender.class);

	public int getSuccessCount() {
		return successCount.get();
	}

	public int getQueueNumber() {
		return queueNumber;
	}

	public void setQueueNumber(int queueNumber) {
		this.queueNumber = queueNumber;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getFailedCount() {
		return failedCount.get();
	}

	public void incSuccessCount() {
		successCount.incrementAndGet();

	}

	public void incFailedCount() {
		failedCount.incrementAndGet();
	}

	public void setFailedIndex(String index) {
		// Default retry is zero
		failedIndexes.put(index, 0);
	}

	public void printQueueStats() {
		logger.debug("QueueNumber: " + getQueueNumber() + "\tSucessfulMessage: " + getSuccessCount() + "\t Failed: "
				+ getFailedCount() + "\t Failed list size" + failedIndexes.size());
	}

	public void printFailedIndex() {
		if (failedIndexes.isEmpty())
			return;
		StringBuilder appendedResult = new StringBuilder("");
		for (String key : failedIndexes.keySet()) {
			appendedResult.append(key + " ");
		}
		logger.debug("Queue Number:" + queueNumber);
		logger.debug(appendedResult.toString());

	}
}