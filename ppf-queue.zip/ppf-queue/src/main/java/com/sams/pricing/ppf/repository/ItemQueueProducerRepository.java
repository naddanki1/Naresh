package com.sams.pricing.ppf.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sams.pricing.ppf.domain.Item;

public interface ItemQueueProducerRepository extends JpaRepository<Item, Integer> {
	@Query("SELECT i FROM Item i WHERE SYS_START_TM >= (:sysStartTm) AND ITEM_NBR<=12000")
	public List<Object> findBySysStartTm(@Param("sysStartTm") Date sysStartTm);
}
