package com.sams.pricing.ppf.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="ITEM_DC",schema="T7SAMITM")
//@IdClass(value = ItemDcKey.class)
public class ItemDc 
{
	@EmbeddedId
	private ItemDcKey itemDcKey;
	
	public ItemDcKey getItemDcKey() {
		return itemDcKey;
	}
	public void setItemDcKey(ItemDcKey itemDcKey) {
		this.itemDcKey = itemDcKey;
	}
	Integer totOnHandQty ;
	Integer onOrdQty ;
	Integer reservedQty ;
	Integer allocatedQty ;
	Integer leadTimeQty ;
	Character tempNotAvailInd ;
	Character deferBondTaxInd ;
	Character dcCancelOutInd ;
	Double inventoryAmt ;
	Integer imptStrgDcNbr ;
	Character itemStatusCode ;
	Date estOutOfStckDt;
	Double vnpkCostAmt ;
	Double deliveredCostAmt ;
	Double whpkSellAmt ;
	Integer ytdVnpkRcvdQty ;
	Double ytdWhpkSellAmt ;
	Integer ytdUnitSalesQty ;
	Integer qtdUnitSalesQty ;
	Integer qtdVnpkRcvdQty ;
	Character crossrefPrimeInd ;
	Timestamp lastUpdateTs ;
	String itemfileSourceNm ;
	Integer vndrMinOrdQty ;
	Integer vndrMinordUomCd ;
	Integer palletTiQty ;
	Integer paletHiQty ;
	Integer vndrIncrmOrdQty ;
	Integer stapleOnOrdQty ;
	String lastUpdatePgmId ;
	Character itemRplnshblInd ;
	Character invtRequiredInd ;
	Integer lblNotInvcQty ;
	Date cancelWhnOutDt ;
	Character outReplPrtyInd ;
	Character dcFixedSlotInd ;
	Date lastRcvdDate ;
	String lastUpdateUserid ;
	Integer whpkSellChgRsnCd ;
	Integer totOnHandEachQty ;
	Integer onOrdrEachQty ;
	Integer reservedEachQty ;
	Integer ytdEachRcvdQty ;
	Integer vndrMinEachOrdQty ;
	Integer qtdEachRcvdQty ;
	Integer vndrIncrmEachOrdQty ;
	Integer stapleOnEachOrdQty ;
	Integer dlyOutOfStockCaseQty ;
	Integer wtdOutOfStockCaseQty ;
	Integer dailyShipCaseQty ;
	Integer wtdShipCaseQty ;
	Integer wtdWTDdistrShipCaseQty ;
	Double avgCaseWgtQty ;
	Integer turnOnhandCaseQty ;
	Integer distrOnhandCaseQty ;
	Integer ossOnhandCaseQty ;
	Integer ytdRcvdCaseQty ;
	Integer buyingMultipleQty ;
	Double unabsorbedItemCostAmt ;
	Integer shlfLifeDaysQty ;
	Integer whseTiQty ;
	Integer whseHiQty ;
	String slotId ;
	Double avgDistroCostAmt ;
	Double avgDistroWgtQty ;
	Double vnpkColCostAmt ;
	Integer dailyDemandQty ;
	String replMgrUserid ;
	Double caseUpcNbr ;
	Integer minRcvngDaysQty ;
	Integer vendorNbr ;
	Integer vendorDeptNbr ;
	Integer vendorSeqNbr ;
	private Timestamp sysStartTm;
	
	
	public Integer getTotOnHandQty() {
		return totOnHandQty;
	}
	public void setTotOnHandQty(Integer totOnHandQty) {
		this.totOnHandQty = totOnHandQty;
	}
	public Integer getOnOrdQty() {
		return onOrdQty;
	}
	public void setOnOrdQty(Integer onOrdQty) {
		this.onOrdQty = onOrdQty;
	}
	public Integer getReservedQty() {
		return reservedQty;
	}
	public void setReservedQty(Integer reservedQty) {
		this.reservedQty = reservedQty;
	}
	public Integer getAllocatedQty() {
		return allocatedQty;
	}
	public void setAllocatedQty(Integer allocatedQty) {
		this.allocatedQty = allocatedQty;
	}
	public Integer getLeadTimeQty() {
		return leadTimeQty;
	}
	public void setLeadTimeQty(Integer leadTimeQty) {
		this.leadTimeQty = leadTimeQty;
	}
	public Character getTempNotAvailInd() {
		return tempNotAvailInd;
	}
	public void setTempNotAvailInd(Character tempNotAvailInd) {
		this.tempNotAvailInd = tempNotAvailInd;
	}
	public Character getDeferBondTaxInd() {
		return deferBondTaxInd;
	}
	public void setDeferBondTaxInd(Character deferBondTaxInd) {
		this.deferBondTaxInd = deferBondTaxInd;
	}
	public Character getDcCancelOutInd() {
		return dcCancelOutInd;
	}
	public void setDcCancelOutInd(Character dcCancelOutInd) {
		this.dcCancelOutInd = dcCancelOutInd;
	}
	public Double getInventoryAmt() {
		return inventoryAmt;
	}
	public void setInventoryAmt(Double inventoryAmt) {
		this.inventoryAmt = inventoryAmt;
	}
	public Integer getImptStrgDcNbr() {
		return imptStrgDcNbr;
	}
	public void setImptStrgDcNbr(Integer imptStrgDcNbr) {
		this.imptStrgDcNbr = imptStrgDcNbr;
	}
	public Character getItemStatusCode() {
		return itemStatusCode;
	}
	public void setItemStatusCode(Character itemStatusCode) {
		this.itemStatusCode = itemStatusCode;
	}
	public Date getEstOutOfStckDt() {
		return estOutOfStckDt;
	}
	public void setEstOutOfStckDt(Date estOutOfStckDt) {
		this.estOutOfStckDt = estOutOfStckDt;
	}
	public Double getVnpkCostAmt() {
		return vnpkCostAmt;
	}
	public void setVnpkCostAmt(Double vnpkCostAmt) {
		this.vnpkCostAmt = vnpkCostAmt;
	}
	public Double getDeliveredCostAmt() {
		return deliveredCostAmt;
	}
	public void setDeliveredCostAmt(Double deliveredCostAmt) {
		this.deliveredCostAmt = deliveredCostAmt;
	}
	public Double getWhpkSellAmt() {
		return whpkSellAmt;
	}
	public void setWhpkSellAmt(Double whpkSellAmt) {
		this.whpkSellAmt = whpkSellAmt;
	}
	public Integer getYtdVnpkRcvdQty() {
		return ytdVnpkRcvdQty;
	}
	public void setYtdVnpkRcvdQty(Integer ytdVnpkRcvdQty) {
		this.ytdVnpkRcvdQty = ytdVnpkRcvdQty;
	}
	public Double getYtdWhpkSellAmt() {
		return ytdWhpkSellAmt;
	}
	public void setYtdWhpkSellAmt(Double ytdWhpkSellAmt) {
		this.ytdWhpkSellAmt = ytdWhpkSellAmt;
	}
	public Integer getYtdUnitSalesQty() {
		return ytdUnitSalesQty;
	}
	public void setYtdUnitSalesQty(Integer ytdUnitSalesQty) {
		this.ytdUnitSalesQty = ytdUnitSalesQty;
	}
	public Integer getQtdUnitSalesQty() {
		return qtdUnitSalesQty;
	}
	public void setQtdUnitSalesQty(Integer qtdUnitSalesQty) {
		this.qtdUnitSalesQty = qtdUnitSalesQty;
	}
	public Integer getQtdVnpkRcvdQty() {
		return qtdVnpkRcvdQty;
	}
	public void setQtdVnpkRcvdQty(Integer qtdVnpkRcvdQty) {
		this.qtdVnpkRcvdQty = qtdVnpkRcvdQty;
	}
	public Character getCrossrefPrimeInd() {
		return crossrefPrimeInd;
	}
	public void setCrossrefPrimeInd(Character crossrefPrimeInd) {
		this.crossrefPrimeInd = crossrefPrimeInd;
	}
	public Timestamp getLastUpdateTs() {
		return lastUpdateTs;
	}
	public void setLastUpdateTs(Timestamp lastUpdateTs) {
		this.lastUpdateTs = lastUpdateTs;
	}
	public String getItemfileSourceNm() {
		return itemfileSourceNm;
	}
	public void setItemfileSourceNm(String itemfileSourceNm) {
		this.itemfileSourceNm = itemfileSourceNm;
	}
	public Integer getVndrMinOrdQty() {
		return vndrMinOrdQty;
	}
	public void setVndrMinOrdQty(Integer vndrMinOrdQty) {
		this.vndrMinOrdQty = vndrMinOrdQty;
	}
	public Integer getVndrMinordUomCd() {
		return vndrMinordUomCd;
	}
	public void setVndrMinordUomCd(Integer vndrMinordUomCd) {
		this.vndrMinordUomCd = vndrMinordUomCd;
	}
	public Integer getPalletTiQty() {
		return palletTiQty;
	}
	public void setPalletTiQty(Integer palletTiQty) {
		this.palletTiQty = palletTiQty;
	}
	public Integer getPaletHiQty() {
		return paletHiQty;
	}
	public void setPaletHiQty(Integer paletHiQty) {
		this.paletHiQty = paletHiQty;
	}
	public Integer getVndrIncrmOrdQty() {
		return vndrIncrmOrdQty;
	}
	public void setVndrIncrmOrdQty(Integer vndrIncrmOrdQty) {
		this.vndrIncrmOrdQty = vndrIncrmOrdQty;
	}
	public Integer getStapleOnOrdQty() {
		return stapleOnOrdQty;
	}
	public void setStapleOnOrdQty(Integer stapleOnOrdQty) {
		this.stapleOnOrdQty = stapleOnOrdQty;
	}
	public String getLastUpdatePgmId() {
		return lastUpdatePgmId;
	}
	public void setLastUpdatePgmId(String lastUpdatePgmId) {
		this.lastUpdatePgmId = lastUpdatePgmId;
	}
	public Character getItemRplnshblInd() {
		return itemRplnshblInd;
	}
	public void setItemRplnshblInd(Character itemRplnshblInd) {
		this.itemRplnshblInd = itemRplnshblInd;
	}
	public Character getInvtRequiredInd() {
		return invtRequiredInd;
	}
	public void setInvtRequiredInd(Character invtRequiredInd) {
		this.invtRequiredInd = invtRequiredInd;
	}
	public Integer getLblNotInvcQty() {
		return lblNotInvcQty;
	}
	public void setLblNotInvcQty(Integer lblNotInvcQty) {
		this.lblNotInvcQty = lblNotInvcQty;
	}
	public Date getCancelWhnOutDt() {
		return cancelWhnOutDt;
	}
	public void setCancelWhnOutDt(Date cancelWhnOutDt) {
		this.cancelWhnOutDt = cancelWhnOutDt;
	}
	public Character getOutReplPrtyInd() {
		return outReplPrtyInd;
	}
	public void setOutReplPrtyInd(Character outReplPrtyInd) {
		this.outReplPrtyInd = outReplPrtyInd;
	}
	public Character getDcFixedSlotInd() {
		return dcFixedSlotInd;
	}
	public void setDcFixedSlotInd(Character dcFixedSlotInd) {
		this.dcFixedSlotInd = dcFixedSlotInd;
	}
	public Date getLastRcvdDate() {
		return lastRcvdDate;
	}
	public void setLastRcvdDate(Date lastRcvdDate) {
		this.lastRcvdDate = lastRcvdDate;
	}
	public String getLastUpdateUserid() {
		return lastUpdateUserid;
	}
	public void setLastUpdateUserid(String lastUpdateUserid) {
		this.lastUpdateUserid = lastUpdateUserid;
	}
	public Integer getWhpkSellChgRsnCd() {
		return whpkSellChgRsnCd;
	}
	public void setWhpkSellChgRsnCd(Integer whpkSellChgRsnCd) {
		this.whpkSellChgRsnCd = whpkSellChgRsnCd;
	}
	public Integer getTotOnHandEachQty() {
		return totOnHandEachQty;
	}
	public void setTotOnHandEachQty(Integer totOnHandEachQty) {
		this.totOnHandEachQty = totOnHandEachQty;
	}
	public Integer getonOrdrEachQty() {
		return onOrdrEachQty;
	}
	public void setonOrdrEachQty(Integer onOrdrEachQty) {
		this.onOrdrEachQty = onOrdrEachQty;
	}
	public Integer getReservedEachQty() {
		return reservedEachQty;
	}
	public void setReservedEachQty(Integer reservedEachQty) {
		this.reservedEachQty = reservedEachQty;
	}
	public Integer getYtdEachRcvdQty() {
		return ytdEachRcvdQty;
	}
	public void setYtdEachRcvdQty(Integer ytdEachRcvdQty) {
		this.ytdEachRcvdQty = ytdEachRcvdQty;
	}
	public Integer getVndrMinEachOrdQty() {
		return vndrMinEachOrdQty;
	}
	public void setVndrMinEachOrdQty(Integer vndrMinEachOrdQty) {
		this.vndrMinEachOrdQty = vndrMinEachOrdQty;
	}
	public Integer getQtdEachRcvdQty() {
		return qtdEachRcvdQty;
	}
	public void setQtdEachRcvdQty(Integer qtdEachRcvdQty) {
		this.qtdEachRcvdQty = qtdEachRcvdQty;
	}
	public Integer getVndrIncrmEachOrdQty() {
		return vndrIncrmEachOrdQty;
	}
	public void setVndrIncrmEachOrdQty(Integer vndrIncrmEachOrdQty) {
		this.vndrIncrmEachOrdQty = vndrIncrmEachOrdQty;
	}
	public Integer getStapleOnEachOrdQty() {
		return stapleOnEachOrdQty;
	}
	public void setStapleOnEachOrdQty(Integer stapleOnEachOrdQty) {
		this.stapleOnEachOrdQty = stapleOnEachOrdQty;
	}
	public Integer getDlyOutOfStockCaseQty() {
		return dlyOutOfStockCaseQty;
	}
	public void setDlyOutOfStockCaseQty(Integer dlyOutOfStockCaseQty) {
		this.dlyOutOfStockCaseQty = dlyOutOfStockCaseQty;
	}
	public Integer getWtdOutOfStockCaseQty() {
		return wtdOutOfStockCaseQty;
	}
	public void setWtdOutOfStockCaseQty(Integer wtdOutOfStockCaseQty) {
		this.wtdOutOfStockCaseQty = wtdOutOfStockCaseQty;
	}
	public Integer getDailyShipCaseQty() {
		return dailyShipCaseQty;
	}
	public void setDailyShipCaseQty(Integer dailyShipCaseQty) {
		this.dailyShipCaseQty = dailyShipCaseQty;
	}
	public Integer getWtdShipCaseQty() {
		return wtdShipCaseQty;
	}
	public void setWtdShipCaseQty(Integer wtdShipCaseQty) {
		this.wtdShipCaseQty = wtdShipCaseQty;
	}
	public Integer getWtdWTDdistrShipCaseQty() {
		return wtdWTDdistrShipCaseQty;
	}
	public void setWtdWTDdistrShipCaseQty(Integer wtdWTDdistrShipCaseQty) {
		this.wtdWTDdistrShipCaseQty = wtdWTDdistrShipCaseQty;
	}
	public Double getAvgCaseWgtQty() {
		return avgCaseWgtQty;
	}
	public void setAvgCaseWgtQty(Double avgCaseWgtQty) {
		this.avgCaseWgtQty = avgCaseWgtQty;
	}
	public Integer getTurnOnhandCaseQty() {
		return turnOnhandCaseQty;
	}
	public void setTurnOnhandCaseQty(Integer turnOnhandCaseQty) {
		this.turnOnhandCaseQty = turnOnhandCaseQty;
	}
	public Integer getDistrOnhandCaseQty() {
		return distrOnhandCaseQty;
	}
	public void setDistrOnhandCaseQty(Integer distrOnhandCaseQty) {
		this.distrOnhandCaseQty = distrOnhandCaseQty;
	}
	public Integer getOssOnhandCaseQty() {
		return ossOnhandCaseQty;
	}
	public void setOssOnhandCaseQty(Integer ossOnhandCaseQty) {
		this.ossOnhandCaseQty = ossOnhandCaseQty;
	}
	public Integer getYtdRcvdCaseQty() {
		return ytdRcvdCaseQty;
	}
	public void setYtdRcvdCaseQty(Integer ytdRcvdCaseQty) {
		this.ytdRcvdCaseQty = ytdRcvdCaseQty;
	}
	public Integer getBuyingMultipleQty() {
		return buyingMultipleQty;
	}
	public void setBuyingMultipleQty(Integer buyingMultipleQty) {
		this.buyingMultipleQty = buyingMultipleQty;
	}
	public Double getUnabsorbedItemCostAmt() {
		return unabsorbedItemCostAmt;
	}
	public void setUnabsorbedItemCostAmt(Double unabsorbedItemCostAmt) {
		this.unabsorbedItemCostAmt = unabsorbedItemCostAmt;
	}
	public Integer getShlfLifeDaysQty() {
		return shlfLifeDaysQty;
	}
	public void setShlfLifeDaysQty(Integer shlfLifeDaysQty) {
		this.shlfLifeDaysQty = shlfLifeDaysQty;
	}
	public Integer getWhseTiQty() {
		return whseTiQty;
	}
	public void setWhseTiQty(Integer whseTiQty) {
		this.whseTiQty = whseTiQty;
	}
	public Integer getWhseHiQty() {
		return whseHiQty;
	}
	public void setWhseHiQty(Integer whseHiQty) {
		this.whseHiQty = whseHiQty;
	}
	public String getSlotId() {
		return slotId;
	}
	public void setSlotId(String slotId) {
		this.slotId = slotId;
	}
	public Double getAvgDistroCostAmt() {
		return avgDistroCostAmt;
	}
	public void setAvgDistroCostAmt(Double avgDistroCostAmt) {
		this.avgDistroCostAmt = avgDistroCostAmt;
	}
	public Double getAvgDistroWgtQty() {
		return avgDistroWgtQty;
	}
	public void setAvgDistroWgtQty(Double avgDistroWgtQty) {
		this.avgDistroWgtQty = avgDistroWgtQty;
	}
	public Double getVnpkColCostAmt() {
		return vnpkColCostAmt;
	}
	public void setVnpkColCostAmt(Double vnpkColCostAmt) {
		this.vnpkColCostAmt = vnpkColCostAmt;
	}
	public Integer getDailyDemandQty() {
		return dailyDemandQty;
	}
	public void setDailyDemandQty(Integer dailyDemandQty) {
		this.dailyDemandQty = dailyDemandQty;
	}
	public String getReplMgrUserid() {
		return replMgrUserid;
	}
	public void setReplMgrUserid(String replMgrUserid) {
		this.replMgrUserid = replMgrUserid;
	}
	public Double getCaseUpcNbr() {
		return caseUpcNbr;
	}
	public void setCaseUpcNbr(Double caseUpcNbr) {
		this.caseUpcNbr = caseUpcNbr;
	}
	public Integer getMinRcvngDaysQty() {
		return minRcvngDaysQty;
	}
	public void setMinRcvngDaysQty(Integer minRcvngDaysQty) {
		this.minRcvngDaysQty = minRcvngDaysQty;
	}
	public Integer getVendorNbr() {
		return vendorNbr;
	}
	public void setVendorNbr(Integer vendorNbr) {
		this.vendorNbr = vendorNbr;
	}
	public Integer getVendorDeptNbr() {
		return vendorDeptNbr;
	}
	public void setVendorDeptNbr(Integer vendorDeptNbr) {
		this.vendorDeptNbr = vendorDeptNbr;
	}
	public Integer getVendorSeqNbr() {
		return vendorSeqNbr;
	}
	public void setVendorSeqNbr(Integer vendorSeqNbr) {
		this.vendorSeqNbr = vendorSeqNbr;
	}
	public Timestamp getSysStartTm() {
		return sysStartTm;
	}
	public void setSysStartTm(Timestamp sysStartTm) {
		this.sysStartTm = sysStartTm;
	}
}
