package com.sams.pricing.ppf.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sams.pricing.ppf.domain.ItemDc;
import com.sams.pricing.ppf.domain.ItemDcKey;

public interface ItemDcQueueProducerRepository extends JpaRepository<ItemDc, ItemDcKey>
{
	
	@Query("SELECT i FROM ItemDc i WHERE SYS_START_TM >= (:sysStartTm)")
	public List<Object> findBySysStartTm(@Param("sysStartTm") Date sysStartTm);

}
