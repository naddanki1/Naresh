package com.sams.pricing.ppf.domain;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ITEM",schema="T7SAMITM")
public class Item 
{
	@Id
	Integer itemNbr;
	
	Integer mdsFamId;
	Integer pluNbr;
	String vendorStockId;
	Integer deptNbr;
	Integer subclassNbr;
	Integer finelineNbr;
	Integer productNbr;
	Integer consumerItemNbr;
	Double upcNbr;
	Integer upcFormatCode;
	Double caseUpcNbr;
	Integer caseUpcFormatCd;
	public Integer getCaseUpcFormatCd() {
		return caseUpcFormatCd;
	}
	public void setCaseUpcFormatCd(Integer caseUpcFormatCd) {
		this.caseUpcFormatCd = caseUpcFormatCd;
	}
	Double whpkUpcNbr;
	Integer whpkUpcFormatCd;
	Character itemStatusCode;
	Date itemCreateDt;
	Date itemOrdEffDate;
	Date itemExpireDate;
	Date sendStoreDate;
	Date vndrFrstAvailDt;
	Date estOutOfStckDt;
	public Integer getItemNbr() {
		return itemNbr;
	}
	public void setItemNbr(Integer itemNbr) {
		this.itemNbr = itemNbr;
	}
	public Integer getMdsFamId() {
		return mdsFamId;
	}
	public void setMdsFamId(Integer mdsFamId) {
		this.mdsFamId = mdsFamId;
	}
	public Integer getPluNbr() {
		return pluNbr;
	}
	public void setPluNbr(Integer pluNbr) {
		this.pluNbr = pluNbr;
	}
	public String getVendorStockId() {
		return vendorStockId;
	}
	public void setVendorStockId(String vendorStockId) {
		this.vendorStockId = vendorStockId;
	}
	public Integer getDeptNbr() {
		return deptNbr;
	}
	public void setDeptNbr(Integer deptNbr) {
		this.deptNbr = deptNbr;
	}
	public Integer getSubclassNbr() {
		return subclassNbr;
	}
	public void setSubclassNbr(Integer subclassNbr) {
		this.subclassNbr = subclassNbr;
	}
	public Integer getFinelineNbr() {
		return finelineNbr;
	}
	public void setFinelineNbr(Integer finelineNbr) {
		this.finelineNbr = finelineNbr;
	}
	public Integer getProductNbr() {
		return productNbr;
	}
	public void setProductNbr(Integer productNbr) {
		this.productNbr = productNbr;
	}
	public Integer getConsumerItemNbr() {
		return consumerItemNbr;
	}
	public void setConsumerItemNbr(Integer consumerItemNbr) {
		this.consumerItemNbr = consumerItemNbr;
	}
	public Double getUpcNbr() {
		return upcNbr;
	}
	public void setUpcNbr(Double upcNbr) {
		this.upcNbr = upcNbr;
	}
	public Integer getUpcFormatCode() {
		return upcFormatCode;
	}
	public void setUpcFormatCode(Integer upcFormatCode) {
		this.upcFormatCode = upcFormatCode;
	}
	public Double getCaseUpcNbr() {
		return caseUpcNbr;
	}
	public void setCaseUpcNbr(Double caseUpcNbr) {
		this.caseUpcNbr = caseUpcNbr;
	}
	
	public Double getWhpkUpcNbr() {
		return whpkUpcNbr;
	}
	public void setWhpkUpcNbr(Double whpkUpcNbr) {
		this.whpkUpcNbr = whpkUpcNbr;
	}
	public Integer getWhpkUpcFormatCd() {
		return whpkUpcFormatCd;
	}
	public void setWhpkUpcFormatCd(Integer whpkUpcFormatCd) {
		this.whpkUpcFormatCd = whpkUpcFormatCd;
	}
	public Character getItemStatusCode() {
		return itemStatusCode;
	}
	public void setItemStatusCode(Character itemStatusCode) {
		this.itemStatusCode = itemStatusCode;
	}
	public Date getItemCreateDt() {
		return itemCreateDt;
	}
	public void setItemCreateDt(Date itemCreateDt) {
		this.itemCreateDt = itemCreateDt;
	}
	public Date getItemOrdEffDate() {
		return itemOrdEffDate;
	}
	public void setItemOrdEffDate(Date itemOrdEffDate) {
		this.itemOrdEffDate = itemOrdEffDate;
	}
	public Date getItemExpireDate() {
		return itemExpireDate;
	}
	public void setItemExpireDate(Date itemExpireDate) {
		this.itemExpireDate = itemExpireDate;
	}
	public Date getSendStoreDate() {
		return sendStoreDate;
	}
	public void setSendStoreDate(Date sendStoreDate) {
		this.sendStoreDate = sendStoreDate;
	}
	public Date getVndrFrstAvailDt() {
		return vndrFrstAvailDt;
	}
	public void setVndrFrstAvailDt(Date vndrFrstAvailDt) {
		this.vndrFrstAvailDt = vndrFrstAvailDt;
	}
	public Date getEstOutOfStckDt() {
		return estOutOfStckDt;
	}
	public void setEstOutOfStckDt(Date estOutOfStckDt) {
		this.estOutOfStckDt = estOutOfStckDt;
	}
	public Integer getItemTypeCode() {
		return itemTypeCode;
	}
	public void setItemTypeCode(Integer itemTypeCode) {
		this.itemTypeCode = itemTypeCode;
	}
	public Integer getReplSubtypeCode() {
		return replSubtypeCode;
	}
	public void setReplSubtypeCode(Integer replSubtypeCode) {
		this.replSubtypeCode = replSubtypeCode;
	}
	public Integer getPromoOrdBookCd() {
		return promoOrdBookCd;
	}
	public void setPromoOrdBookCd(Integer promoOrdBookCd) {
		this.promoOrdBookCd = promoOrdBookCd;
	}
	public Integer getShlfLifeDaysQty() {
		return shlfLifeDaysQty;
	}
	public void setShlfLifeDaysQty(Integer shlfLifeDaysQty) {
		this.shlfLifeDaysQty = shlfLifeDaysQty;
	}
	public Character getReserveMdseInd() {
		return reserveMdseInd;
	}
	public void setReserveMdseInd(Character reserveMdseInd) {
		this.reserveMdseInd = reserveMdseInd;
	}
	public Character getVariableWtInd() {
		return variableWtInd;
	}
	public void setVariableWtInd(Character variableWtInd) {
		this.variableWtInd = variableWtInd;
	}
	public Character getBackrmScaleInd() {
		return backrmScaleInd;
	}
	public void setBackrmScaleInd(Character backrmScaleInd) {
		this.backrmScaleInd = backrmScaleInd;
	}
	public Character getTempSensitiveInd() {
		return tempSensitiveInd;
	}
	public void setTempSensitiveInd(Character tempSensitiveInd) {
		this.tempSensitiveInd = tempSensitiveInd;
	}
	public Integer getDestinationCode() {
		return destinationCode;
	}
	public void setDestinationCode(Integer destinationCode) {
		this.destinationCode = destinationCode;
	}
	public Integer getCnsumableDivNbr() {
		return cnsumableDivNbr;
	}
	public void setCnsumableDivNbr(Integer cnsumableDivNbr) {
		this.cnsumableDivNbr = cnsumableDivNbr;
	}
	public Integer getAccountNbr() {
		return accountNbr;
	}
	public void setAccountNbr(Integer accountNbr) {
		this.accountNbr = accountNbr;
	}
	public Integer getAcctNbrTypeCode() {
		return acctNbrTypeCode;
	}
	public void setAcctNbrTypeCode(Integer acctNbrTypeCode) {
		this.acctNbrTypeCode = acctNbrTypeCode;
	}
	public Character getFppRtrdRangeInd() {
		return fppRtrdRangeInd;
	}
	public void setFppRtrdRangeInd(Character fppRtrdRangeInd) {
		this.fppRtrdRangeInd = fppRtrdRangeInd;
	}
	public Double getFppVolumeQty() {
		return fppVolumeQty;
	}
	public void setFppVolumeQty(Double fppVolumeQty) {
		this.fppVolumeQty = fppVolumeQty;
	}
	public String getFppVolumeUomCd() {
		return fppVolumeUomCd;
	}
	public void setFppVolumeUomCd(String fppVolumeUomCd) {
		this.fppVolumeUomCd = fppVolumeUomCd;
	}
	public Double getItemLengthQty() {
		return itemLengthQty;
	}
	public void setItemLengthQty(Double itemLengthQty) {
		this.itemLengthQty = itemLengthQty;
	}
	public Double getItemHeightQty() {
		return itemHeightQty;
	}
	public void setItemHeightQty(Double itemHeightQty) {
		this.itemHeightQty = itemHeightQty;
	}
	public Double getItemWidthQty() {
		return itemWidthQty;
	}
	public void setItemWidthQty(Double itemWidthQty) {
		this.itemWidthQty = itemWidthQty;
	}
	public String getItemDimUomCode() {
		return itemDimUomCode;
	}
	public void setItemDimUomCode(String itemDimUomCode) {
		this.itemDimUomCode = itemDimUomCode;
	}
	public Double getItemWeightQty() {
		return itemWeightQty;
	}
	public void setItemWeightQty(Double itemWeightQty) {
		this.itemWeightQty = itemWeightQty;
	}
	public String getItemWeightUomCd() {
		return itemWeightUomCd;
	}
	public void setItemWeightUomCd(String itemWeightUomCd) {
		this.itemWeightUomCd = itemWeightUomCd;
	}
	public Double getItemCubeQty() {
		return itemCubeQty;
	}
	public void setItemCubeQty(Double itemCubeQty) {
		this.itemCubeQty = itemCubeQty;
	}
	public String getItemCubeUomCd() {
		return itemCubeUomCd;
	}
	public void setItemCubeUomCd(String itemCubeUomCd) {
		this.itemCubeUomCd = itemCubeUomCd;
	}
	public Double getBaseUnitRtlAmt() {
		return baseUnitRtlAmt;
	}
	public void setBaseUnitRtlAmt(Double baseUnitRtlAmt) {
		this.baseUnitRtlAmt = baseUnitRtlAmt;
	}
	public Double getCustBaseRtlAmt() {
		return custBaseRtlAmt;
	}
	public void setCustBaseRtlAmt(Double custBaseRtlAmt) {
		this.custBaseRtlAmt = custBaseRtlAmt;
	}
	public String getBaseRetailUomCd() {
		return baseRetailUomCd;
	}
	public void setBaseRetailUomCd(String baseRetailUomCd) {
		this.baseRetailUomCd = baseRetailUomCd;
	}
	public Double getSellQty() {
		return sellQty;
	}
	public void setSellQty(Double sellQty) {
		this.sellQty = sellQty;
	}
	public String getSellUomCode() {
		return sellUomCode;
	}
	public void setSellUomCode(String sellUomCode) {
		this.sellUomCode = sellUomCode;
	}
	public Double getPriceCompQty() {
		return priceCompQty;
	}
	public void setPriceCompQty(Double priceCompQty) {
		this.priceCompQty = priceCompQty;
	}
	public String getPriceCompUomCd() {
		return priceCompUomCd;
	}
	public void setPriceCompUomCd(String priceCompUomCd) {
		this.priceCompUomCd = priceCompUomCd;
	}
	public Character getCannedOrderInd() {
		return cannedOrderInd;
	}
	public void setCannedOrderInd(Character cannedOrderInd) {
		this.cannedOrderInd = cannedOrderInd;
	}
	public Character getItemScannableInd() {
		return itemScannableInd;
	}
	public void setItemScannableInd(Character itemScannableInd) {
		this.itemScannableInd = itemScannableInd;
	}
	public Character getShelfLblRqmtInd() {
		return shelfLblRqmtInd;
	}
	public void setShelfLblRqmtInd(Character shelfLblRqmtInd) {
		this.shelfLblRqmtInd = shelfLblRqmtInd;
	}
	public Integer getDietTypeCode() {
		return dietTypeCode;
	}
	public void setDietTypeCode(Integer dietTypeCode) {
		this.dietTypeCode = dietTypeCode;
	}
	public String getItem1_Desc() {
		return item1_Desc;
	}
	public void setItem1_Desc(String item1_Desc) {
		this.item1_Desc = item1_Desc;
	}
	public String getItem2_Desc() {
		return item2_Desc;
	}
	public void setItem2_Desc(String item2_Desc) {
		this.item2_Desc = item2_Desc;
	}
	public String getUpcDesc() {
		return upcDesc;
	}
	public void setUpcDesc(String upcDesc) {
		this.upcDesc = upcDesc;
	}
	public String getshlflbl1_ColrDesc() {
		return shlflbl1_ColrDesc;
	}
	public void setshlflbl1_ColrDesc(String shlflbl1_ColrDesc) {
		this.shlflbl1_ColrDesc = shlflbl1_ColrDesc;
	}
	public String getshlflbl2_SizeDesc() {
		return shlflbl2_SizeDesc;
	}
	public void setshlflbl2_SizeDesc(String shlflbl2_SizeDesc) {
		this.shlflbl2_SizeDesc = shlflbl2_SizeDesc;
	}
	public Character getMbmCode() {
		return mbmCode;
	}
	public void setMbmCode(Character mbmCode) {
		this.mbmCode = mbmCode;
	}
	public Character getItemRplnshblInd() {
		return itemRplnshblInd;
	}
	public void setItemRplnshblInd(Character itemRplnshblInd) {
		this.itemRplnshblInd = itemRplnshblInd;
	}
	public Integer getProjYrSaleQty() {
		return projYrSaleQty;
	}
	public void setProjYrSaleQty(Integer projYrSaleQty) {
		this.projYrSaleQty = projYrSaleQty;
	}
	public Character getReplenishUnitInd() {
		return replenishUnitInd;
	}
	public void setReplenishUnitInd(Character replenishUnitInd) {
		this.replenishUnitInd = replenishUnitInd;
	}
	public Integer getmarshalId() {
		return marshalId;
	}
	public void setmarshalId(Integer marshalId) {
		this.marshalId = marshalId;
	}
	public Integer getWhseAreaCode() {
		return whseAreaCode;
	}
	public void setWhseAreaCode(Integer whseAreaCode) {
		this.whseAreaCode = whseAreaCode;
	}
	public Character getInfrmReordTypCd() {
		return infrmReordTypCd;
	}
	public void setInfrmReordTypCd(Character infrmReordTypCd) {
		this.infrmReordTypCd = infrmReordTypCd;
	}
	public Integer getMinRcvngDaysQty() {
		return minRcvngDaysQty;
	}
	public void setMinRcvngDaysQty(Integer minRcvngDaysQty) {
		this.minRcvngDaysQty = minRcvngDaysQty;
	}
	public Integer getExclusSplyDcNbr() {
		return exclusSplyDcNbr;
	}
	public void setExclusSplyDcNbr(Integer exclusSplyDcNbr) {
		this.exclusSplyDcNbr = exclusSplyDcNbr;
	}
	public String getWhseAlignTypeCd() {
		return whseAlignTypeCd;
	}
	public void setWhseAlignTypeCd(String whseAlignTypeCd) {
		this.whseAlignTypeCd = whseAlignTypeCd;
	}
	public Integer getMinWhseLifeQty() {
		return minWhseLifeQty;
	}
	public void setMinWhseLifeQty(Integer minWhseLifeQty) {
		this.minWhseLifeQty = minWhseLifeQty;
	}
	public Integer getWhseRotationCode() {
		return whseRotationCode;
	}
	public void setWhseRotationCode(Integer whseRotationCode) {
		this.whseRotationCode = whseRotationCode;
	}
	public Integer getPerformRatingCd() {
		return performRatingCd;
	}
	public void setPerformRatingCd(Integer performRatingCd) {
		this.performRatingCd = performRatingCd;
	}
	public Character getCancelWhnOutInd() {
		return cancelWhnOutInd;
	}
	public void setCancelWhnOutInd(Character cancelWhnOutInd) {
		this.cancelWhnOutInd = cancelWhnOutInd;
	}
	public Character getItemImportInd() {
		return itemImportInd;
	}
	public void setItemImportInd(Character itemImportInd) {
		this.itemImportInd = itemImportInd;
	}
	public Double getVnpkCostAmt() {
		return vnpkCostAmt;
	}
	public void setVnpkCostAmt(Double vnpkCostAmt) {
		this.vnpkCostAmt = vnpkCostAmt;
	}
	public Character getVnpkCspkCode() {
		return vnpkCspkCode;
	}
	public void setVnpkCspkCode(Character vnpkCspkCode) {
		this.vnpkCspkCode = vnpkCspkCode;
	}
	public Integer getVnpkQty() {
		return vnpkQty;
	}
	public void setVnpkQty(Integer vnpkQty) {
		this.vnpkQty = vnpkQty;
	}
	public Double getVnpkWeightQty() {
		return vnpkWeightQty;
	}
	public void setVnpkWeightQty(Double vnpkWeightQty) {
		this.vnpkWeightQty = vnpkWeightQty;
	}
	public String getVnpkWeightUomCd() {
		return vnpkWeightUomCd;
	}
	public void setVnpkWeightUomCd(String vnpkWeightUomCd) {
		this.vnpkWeightUomCd = vnpkWeightUomCd;
	}
	public Character getMasterCartonInd() {
		return masterCartonInd;
	}
	public void setMasterCartonInd(Character masterCartonInd) {
		this.masterCartonInd = masterCartonInd;
	}
	public Double getVnpkLengthQty() {
		return vnpkLengthQty;
	}
	public void setVnpkLengthQty(Double vnpkLengthQty) {
		this.vnpkLengthQty = vnpkLengthQty;
	}
	public Double getVnpkWidthQty() {
		return vnpkWidthQty;
	}
	public void setVnpkWidthQty(Double vnpkWidthQty) {
		this.vnpkWidthQty = vnpkWidthQty;
	}
	public Double getVnpkHeightQty() {
		return vnpkHeightQty;
	}
	public void setVnpkHeightQty(Double vnpkHeightQty) {
		this.vnpkHeightQty = vnpkHeightQty;
	}
	public String getVnpkDimUomCode() {
		return vnpkDimUomCode;
	}
	public void setVnpkDimUomCode(String vnpkDimUomCode) {
		this.vnpkDimUomCode = vnpkDimUomCode;
	}
	public Double getVnpkCubeQty() {
		return vnpkCubeQty;
	}
	public void setVnpkCubeQty(Double vnpkCubeQty) {
		this.vnpkCubeQty = vnpkCubeQty;
	}
	public String getVnpkCubeUomCd() {
		return vnpkCubeUomCd;
	}
	public void setVnpkCubeUomCd(String vnpkCubeUomCd) {
		this.vnpkCubeUomCd = vnpkCubeUomCd;
	}
	public Character getVnpkWeightFmtCd() {
		return vnpkWeightFmtCd;
	}
	public void setVnpkWeightFmtCd(Character vnpkWeightFmtCd) {
		this.vnpkWeightFmtCd = vnpkWeightFmtCd;
	}
	public Integer getVndrMinOrdQty() {
		return vndrMinOrdQty;
	}
	public void setVndr_MinOrdQty(Integer vndrMinOrdQty) {
		this.vndrMinOrdQty = vndrMinOrdQty;
	}
	public String getVndrMinordUomCd() {
		return vndrMinordUomCd;
	}
	public void setVndrMinordUomCd(String vndrMinordUomCd) {
		this.vndrMinordUomCd = vndrMinordUomCd;
	}
	public Integer getPalletTiQty() {
		return palletTiQty;
	}
	public void setPalletTiQty(Integer palletTiQty) {
		this.palletTiQty = palletTiQty;
	}
	public Integer getPalletHiQty() {
		return palletHiQty;
	}
	public void setPalletHiQty(Integer palletHiQty) {
		this.palletHiQty = palletHiQty;
	}
	public Double getWhpkSellAmt() {
		return whpkSellAmt;
	}
	public void setWhpkSellAmt(Double whpkSellAmt) {
		this.whpkSellAmt = whpkSellAmt;
	}
	public Integer getWhpkQty() {
		return whpkQty;
	}
	public void setWhpkQty(Integer whpkQty) {
		this.whpkQty = whpkQty;
	}
	public Double getWhpkLengthQty() {
		return whpkLengthQty;
	}
	public void setWhpkLengthQty(Double whpkLengthQty) {
		this.whpkLengthQty = whpkLengthQty;
	}
	public Double getWhpkWidthQty() {
		return whpkWidthQty;
	}
	public void setWhpkWidthQty(Double whpkWidthQty) {
		this.whpkWidthQty = whpkWidthQty;
	}
	public Double getWhpkCubeQty() {
		return whpkCubeQty;
	}
	public void setWhpkCubeQty(Double whpkCubeQty) {
		this.whpkCubeQty = whpkCubeQty;
	}
	public String getWhpkCubeUomCd() {
		return whpkCubeUomCd;
	}
	public void setWhpkCubeUomCd(String whpkCubeUomCd) {
		this.whpkCubeUomCd = whpkCubeUomCd;
	}
	public Double getWhpkHeightQty() {
		return whpkHeightQty;
	}
	public void setWhpkHeightQty(Double whpkHeightQty) {
		this.whpkHeightQty = whpkHeightQty;
	}
	public String getWhpkDimUomCode() {
		return whpkDimUomCode;
	}
	public void setWhpkDimUomCode(String whpkDimUomCode) {
		this.whpkDimUomCode = whpkDimUomCode;
	}
	public Double getWhpkWeightQty() {
		return whpkWeightQty;
	}
	public void setWhpkWeightQty(Double whpkWeightQty) {
		this.whpkWeightQty = whpkWeightQty;
	}
	public String getWhpkWeightUomCd() {
		return whpkWeightUomCd;
	}
	public void setWhpkWeightUomCd(String whpkWeightUomCd) {
		this.whpkWeightUomCd = whpkWeightUomCd;
	}
	public Integer getWhseMinOrderQty() {
		return whseMinOrderQty;
	}
	public void setWhseMinOrderQty(Integer whseMinOrderQty) {
		this.whseMinOrderQty = whseMinOrderQty;
	}
	public Integer getWhseMaxOrderQty() {
		return whseMaxOrderQty;
	}
	public void setWhseMaxOrderQty(Integer whseMaxOrderQty) {
		this.whseMaxOrderQty = whseMaxOrderQty;
	}
	public Character getWhpkCalcMthdCd() {
		return whpkCalcMthdCd;
	}
	public void setWhpkCalcMthdCd(Character whpkCalcMthdCd) {
		this.whpkCalcMthdCd = whpkCalcMthdCd;
	}
	public Integer getCrushFactorCode() {
		return crushFactorCode;
	}
	public void setCrushFactorCode(Integer crushFactorCode) {
		this.crushFactorCode = crushFactorCode;
	}
	public Character getConveyableInd() {
		return conveyableInd;
	}
	public void setConveyableInd(Character conveyableInd) {
		this.conveyableInd = conveyableInd;
	}
	public Character getPalletSizeCode() {
		return palletSizeCode;
	}
	public void setPalletSizeCode(Character palletSizeCode) {
		this.palletSizeCode = palletSizeCode;
	}
	public Integer getVendorNbr() {
		return vendorNbr;
	}
	public void setVendorNbr(Integer vendorNbr) {
		this.vendorNbr = vendorNbr;
	}
	public Integer getVendorDeptNbr() {
		return vendorDeptNbr;
	}
	public void setVendorDeptNbr(Integer vendorDeptNbr) {
		this.vendorDeptNbr = vendorDeptNbr;
	}
	public Integer getVendorSeqNbr() {
		return vendorSeqNbr;
	}
	public void setVendorSeqNbr(Integer vendorSeqNbr) {
		this.vendorSeqNbr = vendorSeqNbr;
	}
	public String getOriginCountryCd() {
		return originCountryCd;
	}
	public void setOriginCountryCd(String originCountryCd) {
		this.originCountryCd = originCountryCd;
	}
	public Integer getVndrLeadTmQty() {
		return vndrLeadTmQty;
	}
	public void setVndrLeadTmQty(Integer vndrLeadTmQty) {
		this.vndrLeadTmQty = vndrLeadTmQty;
	}
	public Double getPalletRoundPct() {
		return palletRoundPct;
	}
	public void setPalletRoundPct(Double palletRoundPct) {
		this.palletRoundPct = palletRoundPct;
	}
	public Double getFppBtchShrnkQty() {
		return fppBtchShrnkQty;
	}
	public void setFppBtchShrnkQty(Double fppBtchShrnkQty) {
		this.fppBtchShrnkQty = fppBtchShrnkQty;
	}
	public Double getFppEstShrinkPct() {
		return fppEstShrinkPct;
	}
	public void setFppEstShrinkPct(Double fppEstShrinkPct) {
		this.fppEstShrinkPct = fppEstShrinkPct;
	}
	public Integer getAssortmentTypeCd() {
		return assortmentTypeCd;
	}
	public void setAssortmentTypeCd(Integer assortmentTypeCd) {
		this.assortmentTypeCd = assortmentTypeCd;
	}
	public String getTemprUomCode() {
		return temprUomCode;
	}
	public void setTemprUomCode(String temprUomCode) {
		this.temprUomCode = temprUomCode;
	}
	public Integer getIdealTempLoQty() {
		return idealTempLoQty;
	}
	public void setIdealTempLoQty(Integer idealTempLoQty) {
		this.idealTempLoQty = idealTempLoQty;
	}
	public Integer getIdealTempHiQty() {
		return idealTempHiQty;
	}
	public void setIdealTempHiQty(Integer idealTempHiQty) {
		this.idealTempHiQty = idealTempHiQty;
	}
	public Integer getAcceptTempLoQty() {
		return acceptTempLoQty;
	}
	public void setAcceptTempLoQty(Integer acceptTempLoQty) {
		this.acceptTempLoQty = acceptTempLoQty;
	}
	public Integer getAcceptTempHiQty() {
		return acceptTempHiQty;
	}
	public void setAcceptTempHiQty(Integer acceptTempHiQty) {
		this.acceptTempHiQty = acceptTempHiQty;
	}
	public String getLastUpdatePgmId() {
		return lastUpdatePgmId;
	}
	public void setLastUpdatePgmId(String lastUpdatePgmId) {
		this.lastUpdatePgmId = lastUpdatePgmId;
	}
	public String getLastUpdateUserid() {
		return lastUpdateUserid;
	}
	public void setLastUpdateUserid(String lastUpdateUserid) {
		this.lastUpdateUserid = lastUpdateUserid;
	}
	public Timestamp getLastUpdateTs() {
		return lastUpdateTs;
	}
	public void setLastUpdateTs(Timestamp lastUpdateTs) {
		this.lastUpdateTs = lastUpdateTs;
	}
	public String getItemfileSourceNm() {
		return itemfileSourceNm;
	}
	public void setItemfileSourceNm(String itemfileSourceNm) {
		this.itemfileSourceNm = itemfileSourceNm;
	}
	public Character getSecurityTagInd() {
		return securityTagInd;
	}
	public void setSecurityTagInd(Character securityTagInd) {
		this.securityTagInd = securityTagInd;
	}
	public Character getShelfRotationInd() {
		return shelfRotationInd;
	}
	public void setShelfRotationInd(Character shelfRotationInd) {
		this.shelfRotationInd = shelfRotationInd;
	}
	public Character getGuarSalesInd() {
		return guarSalesInd;
	}
	public void setGuarSalesInd(Character guarSalesInd) {
		this.guarSalesInd = guarSalesInd;
	}
	public Double getMfgrSugdRtlAmt() {
		return mfgrSugdRtlAmt;
	}
	public void setMfgrSugdRtlAmt(Double mfgrSugdRtlAmt) {
		this.mfgrSugdRtlAmt = mfgrSugdRtlAmt;
	}
	public Double getMfgrPrePriceAmt() {
		return mfgrPrePriceAmt;
	}
	public void setMfgrPrePriceAmt(Double mfgrPrePriceAmt) {
		this.mfgrPrePriceAmt = mfgrPrePriceAmt;
	}
	public Date getVndrFirstOrdDt() {
		return vndrFirstOrdDt;
	}
	public void setVndrFirstOrdDt(Date vndrFirstOrdDt) {
		this.vndrFirstOrdDt = vndrFirstOrdDt;
	}
	public Date getVndrFirstShipDt() {
		return vndrFirstShipDt;
	}
	public void setVndrFirstShipDt(Date vndrFirstShipDt) {
		this.vndrFirstShipDt = vndrFirstShipDt;
	}
	public Date getLastOrderDate() {
		return lastOrderDate;
	}
	public void setLastOrderDate(Date lastOrderDate) {
		this.lastOrderDate = lastOrderDate;
	}
	public Date getVndrLastShipDt() {
		return vndrLastShipDt;
	}
	public void setVndrLastShipDt(Date vndrLastShipDt) {
		this.vndrLastShipDt = vndrLastShipDt;
	}
	public Integer getBrandId() {
		return brandId;
	}
	public void setBrandId(Integer brandId) {
		this.brandId = brandId;
	}
	public String getSigningDesc() {
		return signingDesc;
	}
	public void setSigningDesc(String signingDesc) {
		this.signingDesc = signingDesc;
	}
	public String getShopDesc() {
		return shopDesc;
	}
	public void setShopDesc(String shopDesc) {
		this.shopDesc = shopDesc;
	}
	
	public Character getVariableCompInd() {
		return variableCompInd;
	}
	public void setVariableCompInd(Character variableCompInd) {
		this.variableCompInd = variableCompInd;
	}
	public Integer getMdseCatgNbr() {
		return mdseCatgNbr;
	}
	public void setMdseCatgNbr(Integer mdseCatgNbr) {
		this.mdseCatgNbr = mdseCatgNbr;
	}
	public Integer getMdseSubcatgNbr() {
		return mdseSubcatgNbr;
	}
	public void setMdseSubcatgNbr(Integer mdseSubcatgNbr) {
		this.mdseSubcatgNbr = mdseSubcatgNbr;
	}
	public Integer getFppTrgtThrwyPct() {
		return fppTrgtThrwyPct;
	}
	public void setFppTrgtThrwyPct(Integer fppTrgtThrwyPct) {
		this.fppTrgtThrwyPct = fppTrgtThrwyPct;
	}
	public Date getItemStatusChgDt() {
		return itemStatusChgDt;
	}
	public void setItemStatusChgDt(Date itemStatusChgDt) {
		this.itemStatusChgDt = itemStatusChgDt;
	}
	public Integer getStoreFormatCode() {
		return storeFormatCode;
	}
	public void setStoreFormatCode(Integer storeFormatCode) {
		this.storeFormatCode = storeFormatCode;
	}
	public Integer getBuyingRegionCode() {
		return buyingRegionCode;
	}
	public void setBuyingRegionCode(Integer buyingRegionCode) {
		this.buyingRegionCode = buyingRegionCode;
	}
	public Integer getSellPackageQty() {
		return sellPackageQty;
	}
	public void setSellPackageQty(Integer sellPackageQty) {
		this.sellPackageQty = sellPackageQty;
	}
	public String getSellUnitUomCode() {
		return sellUnitUomCode;
	}
	public void setSellUnitUomCode(String sellUnitUomCode) {
		this.sellUnitUomCode = sellUnitUomCode;
	}
	public Integer getCompPackageQty() {
		return compPackageQty;
	}
	public void setCompPackageQty(Integer compPackageQty) {
		this.compPackageQty = compPackageQty;
	}
	public Double getCompUnitQty() {
		return compUnitQty;
	}
	public void setCompUnitQty(Double compUnitQty) {
		this.compUnitQty = compUnitQty;
	}
	public String getCompUnitUomCode() {
		return compUnitUomCode;
	}
	public void setCompUnitUomCode(String compUnitUomCode) {
		this.compUnitUomCode = compUnitUomCode;
	}
	public Character getCatchWeightInd() {
		return catchWeightInd;
	}
	public void setCatchWeightInd(Character catchWeightInd) {
		this.catchWeightInd = catchWeightInd;
	}
	public Character getNeverOutInd() {
		return neverOutInd;
	}
	public void setNeverOutInd(Character neverOutInd) {
		this.neverOutInd = neverOutInd;
	}
	public Integer getAcctgDeptNbr() {
		return acctgDeptNbr;
	}
	public void setAcctgDeptNbr(Integer acctgDeptNbr) {
		this.acctgDeptNbr = acctgDeptNbr;
	}
	public Integer getSeasonCode() {
		return seasonCode;
	}
	public void setSeasonCode(Integer seasonCode) {
		this.seasonCode = seasonCode;
	}
	public Integer getSeasonYear() {
		return seasonYear;
	}
	public void setSeasonYear(Integer seasonYear) {
		this.seasonYear = seasonYear;
	}
	public Integer getLicenseCode() {
		return licenseCode;
	}
	public void setLicenseCode(Integer licenseCode) {
		this.licenseCode = licenseCode;
	}
	public Double getVnpkNetwgtQty() {
		return vnpkNetwgtQty;
	}
	public void setVnpkNetwgtQty(Double vnpkNetwgtQty) {
		this.vnpkNetwgtQty = vnpkNetwgtQty;
	}
	public String getVnpkNetwgtUomCd() {
		return vnpkNetwgtUomCd;
	}
	public void setVnpkNetwgtUomCd(String vnpkNetwgtUomCd) {
		this.vnpkNetwgtUomCd = vnpkNetwgtUomCd;
	}
	
	public Double getPalletUpcNbr() {
		return palletUpcNbr;
	}
	public void setPalletUpcNbr(Double palletUpcNbr) {
		this.palletUpcNbr = palletUpcNbr;
	}
	public Integer getPalletUpcFmtCd() {
		return palletUpcFmtCd;
	}
	public void setPalletUpcFmtCd(Integer palletUpcFmtCd) {
		this.palletUpcFmtCd = palletUpcFmtCd;
	}
	public Character getRfidInd() {
		return rfidInd;
	}
	public void setRfidInd(Character rfidInd) {
		this.rfidInd = rfidInd;
	}
	public Integer getReserveMdseCode() {
		return reserveMdseCode;
	}
	public void setReserveMdseCode(Integer reserveMdseCode) {
		this.reserveMdseCode = reserveMdseCode;
	}
	
	public Integer getSegregationCode() {
		return segregationCode;
	}
	public void setSegregationCode(Integer segregationCode) {
		this.segregationCode = segregationCode;
	}
	public Integer getMdseProgramId() {
		return mdseProgramId;
	}
	public void setMdseProgramId(Integer mdseProgramId) {
		this.mdseProgramId = mdseProgramId;
	}
	public Integer getCommodityId() {
		return commodityId;
	}
	public void setCommodityId(Integer commodityId) {
		this.commodityId = commodityId;
	}
	public Integer getAbcPharmaNbr() {
		return abcPharmaNbr;
	}
	public void setAbcPharmaNbr(Integer abcPharmaNbr) {
		this.abcPharmaNbr = abcPharmaNbr;
	}
	public Character getChemicalInd() {
		return chemicalInd;
	}
	public void setChemicalInd(Character chemicalInd) {
		this.chemicalInd = chemicalInd;
	}
	public Character getPesticideInd() {
		return pesticideInd;
	}
	public void setPesticideInd(Character pesticideInd) {
		this.pesticideInd = pesticideInd;
	}
	public Character getAerosalInd() {
		return aerosalInd;
	}
	public void setAerosalInd(Character aerosalInd) {
		this.aerosalInd = aerosalInd;
	}
	
	public Integer getFhsDcSlotCode() {
		return fhsDcSlotCode;
	}
	public void setFhsDcSlotCode(Integer fhsDcSlotCode) {
		this.fhsDcSlotCode = fhsDcSlotCode;
	}
	public Integer getPresnUnitQty() {
		return presnUnitQty;
	}
	public void setPresnUnitQty(Integer presnUnitQty) {
		this.presnUnitQty = presnUnitQty;
	}
	public Character getSuppDisplayInd() {
		return suppDisplayInd;
	}
	public void setSuppDisplayInd(Character suppDisplayInd) {
		this.suppDisplayInd = suppDisplayInd;
	}
	public Character getFsaInd() {
		return fsaInd;
	}
	public void setFsaInd(Character fsaInd) {
		this.fsaInd = fsaInd;
	}
	public Double getStrShlfLfHrQty() {
		return strShlfLfHrQty;
	}
	public void setStrShlfLfHrQty(Double strShlfLfHrQty) {
		this.strShlfLfHrQty = strShlfLfHrQty;
	}
	public Double getFppPrepnHrQty() {
		return fppPrepnHrQty;
	}
	public void setFppPrepnHrQty(Double fppPrepnHrQty) {
		this.fppPrepnHrQty = fppPrepnHrQty;
	}
	public Character getCntrlSbsncInd() {
		return cntrlSbsncInd;
	}
	public void setCntrlSbsncInd(Character cntrlSbsncInd) {
		this.cntrlSbsncInd = cntrlSbsncInd;
	}
	public Character getpromptPriceInd() {
		return promptPriceInd;
	}
	public void setpromptPriceInd(Character promptPriceInd) {
		this.promptPriceInd = promptPriceInd;
	}
	public Character getNonMbrUpchrgInd() {
		return nonMbrUpchrgInd;
	}
	public void setNonMbrUpchrgInd(Character nonMbrUpchrgInd) {
		this.nonMbrUpchrgInd = nonMbrUpchrgInd;
	}
	
	public Integer getVndrIncrmOrdQty() {
		return vndrIncrmOrdQty;
	}
	public void setVndrIncrmOrdQty(Integer vndrIncrmOrdQty) {
		this.vndrIncrmOrdQty = vndrIncrmOrdQty;
	}
	public Character getRtlNotfyStrInd() {
		return rtlNotfyStrInd;
	}
	public void setRtlNotfyStrInd(Character rtlNotfyStrInd) {
		this.rtlNotfyStrInd = rtlNotfyStrInd;
	}
	public Double getOrdSizngFctrQty() {
		return ordSizngFctrQty;
	}
	public void setOrdSizngFctrQty(Double ordSizngFctrQty) {
		this.ordSizngFctrQty = ordSizngFctrQty;
	}
	public Character getRppcInd() {
		return rppcInd;
	}
	public void setRppcInd(Character rppcInd) {
		this.rppcInd = rppcInd;
	}
	public Character getDcDeaReportInd() {
		return dcDeaReportInd;
	}
	public void setDcDeaReportInd(Character dcDeaReportInd) {
		this.dcDeaReportInd = dcDeaReportInd;
	}
	public void setVndrMinOrdQty(Integer vndrMinOrdQty) {
		this.vndrMinOrdQty = vndrMinOrdQty;
	}
	public Character getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(Character countryCode) {
		this.countryCode = countryCode;
	}
	public String getSanitaryRegtnNbr() {
		return sanitaryRegtnNbr;
	}
	public void setSanitaryRegtnNbr(String sanitaryRegtnNbr) {
		this.sanitaryRegtnNbr = sanitaryRegtnNbr;
	}
	public Date getSanitRegtnExpDt() {
		return sanitRegtnExpDt;
	}
	public void setSanitRegtnExpDt(Date sanitRegtnExpDt) {
		this.sanitRegtnExpDt = sanitRegtnExpDt;
	}
	public Character getDiscountInd() {
		return discountInd;
	}
	public void setDiscountInd(Character discountInd) {
		this.discountInd = discountInd;
	}
	public Double getWhpkNetwgtQty() {
		return whpkNetwgtQty;
	}
	public void setWhpkNetwgtQty(Double whpkNetwgtQty) {
		this.whpkNetwgtQty = whpkNetwgtQty;
	}
	public Character getAltChnnlSrcInd() {
		return altChnnlSrcInd;
	}
	public void setAltChnnlSrcInd(Character altChnnlSrcInd) {
		this.altChnnlSrcInd = altChnnlSrcInd;
	}
	public Double getReplGroupNbr() {
		return replGroupNbr;
	}
	public void setReplGroupNbr(Double replGroupNbr) {
		this.replGroupNbr = replGroupNbr;
	}
	public Double getFppMinVolumeQty() {
		return fppMinVolumeQty;
	}
	public void setFppMinVolumeQty(Double fppMinVolumeQty) {
		this.fppMinVolumeQty = fppMinVolumeQty;
	}
	public Integer getQualityCntrlCd() {
		return qualityCntrlCd;
	}
	public void setQualityCntrlCd(Integer qualityCntrlCd) {
		this.qualityCntrlCd = qualityCntrlCd;
	}
	public Character getHealthIncentiveEligInd() {
		return healthIncentiveEligInd;
	}
	public void setHealthIncentiveEligInd(Character healthIncentiveEligInd) {
		this.healthIncentiveEligInd = healthIncentiveEligInd;
	}
	public Double getItemVolumeQty() {
		return itemVolumeQty;
	}
	public void setItemVolumeQty(Double itemVolumeQty) {
		this.itemVolumeQty = itemVolumeQty;
	}
	public String getItemVolumeUomCd() {
		return itemVolumeUomCd;
	}
	public void setItemVolumeUomCd(String itemVolumeUomCd) {
		this.itemVolumeUomCd = itemVolumeUomCd;
	}
	public Double getAlcoholPct() {
		return alcoholPct;
	}
	public void setAlcoholPct(Double alcoholPct) {
		this.alcoholPct = alcoholPct;
	}
	public Character getMinPriceInd() {
		return minPriceInd;
	}
	public void setMinPriceInd(Character minPriceInd) {
		this.minPriceInd = minPriceInd;
	}
	public Integer getBrandAcquisitionCode() {
		return brandAcquisitionCode;
	}
	public void setBrandAcquisitionCode(Integer brandAcquisitionCode) {
		this.brandAcquisitionCode = brandAcquisitionCode;
	}
	public Character getReturnResaleInd() {
		return returnResaleInd;
	}
	public void setReturnResaleInd(Character returnResaleInd) {
		this.returnResaleInd = returnResaleInd;
	}
	public Character getRetailIncludeVatInd() {
		return retailIncludeVatInd;
	}
	public void setRetailIncludeVatInd(Character retailIncludeVatInd) {
		this.retailIncludeVatInd = retailIncludeVatInd;
	}
	public Double getGiftCardFaceAmt() {
		return giftCardFaceAmt;
	}
	public void setGiftCardFaceAmt(Double giftCardFaceAmt) {
		this.giftCardFaceAmt = giftCardFaceAmt;
	}
	public Double getGiftCardFeeAmount() {
		return giftCardFeeAmount;
	}
	public void setGiftCardFeeAmount(Double giftCardFeeAmount) {
		this.giftCardFeeAmount = giftCardFeeAmount;
	}
	public Double getGiftCardFeePercent() {
		return giftCardFeePercent;
	}
	public void setGiftCardFeePercent(Double giftCardFeePercent) {
		this.giftCardFeePercent = giftCardFeePercent;
	}
	public Integer getGiftCardTypeCode() {
		return giftCardTypeCode;
	}
	public void setGiftCardTypeCode(Integer giftCardTypeCode) {
		this.giftCardTypeCode = giftCardTypeCode;
	}
	public Integer getFeaturePresnUnitQty() {
		return featurePresnUnitQty;
	}
	public void setFeaturePresnUnitQty(Integer featurePresnUnitQty) {
		this.featurePresnUnitQty = featurePresnUnitQty;
	}
	public Timestamp getSysStartTm() {
		return sysStartTm;
	}
	public void setSysStartTm(Timestamp sysStartTm) {
		this.sysStartTm = sysStartTm;
	}
	Integer itemTypeCode;
	Integer replSubtypeCode;
	Integer promoOrdBookCd;
	Integer shlfLifeDaysQty;
	Character reserveMdseInd;
	Character variableWtInd;
	Character backrmScaleInd;
	Character tempSensitiveInd;
	Integer destinationCode;
	Integer cnsumableDivNbr;
	Integer accountNbr;
	Integer acctNbrTypeCode;
	Character fppRtrdRangeInd;
	Double fppVolumeQty;
	String fppVolumeUomCd;
	Double itemLengthQty;
	Double itemHeightQty;
	Double itemWidthQty;
	String itemDimUomCode;
	Double itemWeightQty;
	String itemWeightUomCd;
	Double itemCubeQty;
	String itemCubeUomCd;
	Double baseUnitRtlAmt;
	Double custBaseRtlAmt;
	String baseRetailUomCd;
	Double sellQty;
	String sellUomCode;
	Double priceCompQty;
	String priceCompUomCd;
	Character cannedOrderInd;
	Character itemScannableInd;
	Character shelfLblRqmtInd;
	Integer dietTypeCode;
	String item1_Desc;
	String item2_Desc;
	String upcDesc;
	String shlflbl1_ColrDesc;
	String shlflbl2_SizeDesc;
	Character mbmCode;
	Character itemRplnshblInd;
	Integer projYrSaleQty;
	Character replenishUnitInd;
	Integer marshalId;
	Integer whseAreaCode;
	Character infrmReordTypCd;
	Integer minRcvngDaysQty;
	Integer exclusSplyDcNbr;
	String whseAlignTypeCd;
	Integer minWhseLifeQty;
	Integer whseRotationCode;
	Integer performRatingCd;
	Character cancelWhnOutInd;
	Character itemImportInd;
	Double vnpkCostAmt;
	Character vnpkCspkCode;
	Integer vnpkQty;
	Double vnpkWeightQty;
	String vnpkWeightUomCd;
	Character masterCartonInd;
	Double vnpkLengthQty;
	Double vnpkWidthQty;
	Double vnpkHeightQty;
	String vnpkDimUomCode;
	Double vnpkCubeQty;
	String vnpkCubeUomCd;
	Character vnpkWeightFmtCd;
	Integer vndrMinOrdQty;
	String vndrMinordUomCd;
	Integer palletTiQty;
	Integer palletHiQty;
	Double whpkSellAmt;
	Integer whpkQty;
	Double whpkLengthQty;
	Double whpkWidthQty;
	Double whpkCubeQty;
	String whpkCubeUomCd;
	Double whpkHeightQty;
	String whpkDimUomCode;
	Double whpkWeightQty;
	String whpkWeightUomCd;
	Integer whseMinOrderQty;
	Integer whseMaxOrderQty;
	Character whpkCalcMthdCd;
	Integer crushFactorCode;
	Character conveyableInd;
	Character palletSizeCode;
	Integer vendorNbr;
	Integer vendorDeptNbr;
	Integer vendorSeqNbr;
	String originCountryCd;
	Integer vndrLeadTmQty;
	Double palletRoundPct;
	Double fppBtchShrnkQty;
	Double fppEstShrinkPct;
	Integer assortmentTypeCd;
	String temprUomCode;
	Integer idealTempLoQty;
	Integer idealTempHiQty;
	Integer acceptTempLoQty;
	Integer acceptTempHiQty;
	String lastUpdatePgmId;
	String lastUpdateUserid;
	Timestamp lastUpdateTs;
	String itemfileSourceNm;
	Character securityTagInd;
	Character shelfRotationInd;
	Character guarSalesInd;
	Double mfgrSugdRtlAmt;
	Double mfgrPrePriceAmt;
	Date vndrFirstOrdDt;
	Date vndrFirstShipDt;
	Date lastOrderDate;
	Date vndrLastShipDt;
	Integer brandId;
	String signingDesc;
	String shopDesc ;
	Integer vndrIncrmOrdQty ;
	Character variableCompInd ;
	Integer mdseCatgNbr ;
	Integer mdseSubcatgNbr ;
	Integer fppTrgtThrwyPct ;
	Date itemStatusChgDt ;
	Integer storeFormatCode ;
	Integer buyingRegionCode ;
	Integer sellPackageQty ;
	String sellUnitUomCode ;
	Integer compPackageQty ;
	Double compUnitQty ;
	String compUnitUomCode ;
	Character catchWeightInd ;
	Character neverOutInd ;
	Integer acctgDeptNbr ;
	Integer seasonCode ;
	Integer seasonYear ;
	Integer licenseCode ;
	Double vnpkNetwgtQty ;
	String vnpkNetwgtUomCd ;
	Character rtlNotfyStrInd ;
	Double palletUpcNbr ;
	Integer palletUpcFmtCd ;
	Character rfidInd ;
	Integer reserveMdseCode ;
	Double ordSizngFctrQty ;
	Integer segregationCode ;
	Integer mdseProgramId ;
	Integer commodityId ;
	Integer abcPharmaNbr ;
	Character chemicalInd ;
	Character pesticideInd ;
	Character aerosalInd ;
	Character rppcInd ;
	Integer fhsDcSlotCode ;
	Integer presnUnitQty ;
	Character suppDisplayInd ;
	Character fsaInd ;
	Double strShlfLfHrQty ;
	Double fppPrepnHrQty ;
	Character cntrlSbsncInd ;
	Character promptPriceInd ;
	Character nonMbrUpchrgInd ;
	Character dcDeaReportInd ;
	Character countryCode ;
	String sanitaryRegtnNbr ;
	Date sanitRegtnExpDt ;
	Character discountInd ;
	Double whpkNetwgtQty ;
	Character altChnnlSrcInd ;
	Double replGroupNbr ;
	Double fppMinVolumeQty ;
	Integer qualityCntrlCd ;
	Character healthIncentiveEligInd ;
	Double itemVolumeQty ;
	String itemVolumeUomCd ;
	Double alcoholPct ;
	Character minPriceInd ;
	Integer brandAcquisitionCode ;
	Character returnResaleInd ;
	Character retailIncludeVatInd ;
	Double giftCardFaceAmt ;
	Double giftCardFeeAmount ;
	Double giftCardFeePercent ;
	Integer giftCardTypeCode ;
	Integer featurePresnUnitQty ;
	Timestamp sysStartTm ;
}
