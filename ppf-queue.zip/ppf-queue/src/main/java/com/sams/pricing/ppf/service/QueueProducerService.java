package com.sams.pricing.ppf.service;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.tomcat.jni.Time;
import org.omg.CORBA.TIMEOUT;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.microsoft.azure.servicebus.IMessageSender;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import com.sams.pricing.ppf.model.QueueStats;
import com.sams.pricing.ppf.queue.producer.QueueConnectionsHandler;
import com.sams.pricing.ppf.queue.producer.QueueSender;
import com.sams.pricing.ppf.repository.ItemDcQueueProducerRepository;
import com.sams.pricing.ppf.repository.ItemQueueProducerRepository;
import com.sams.pricing.ppf.repository.QueueProducerRepository;

@Service
@EnableScheduling
public class QueueProducerService {
	@Autowired
	QueueProducerRepository queueProducerRepository;
	@Autowired
	ItemQueueProducerRepository itemQueueProducerRepository;
	@Autowired
	ItemDcQueueProducerRepository itemDcQueueProducerRepository;
	@Autowired
	private QueueSender queueSender;
	@Autowired
	QueueConnectionsHandler queueConnectionProperties;

	String previousTimestamp = "2018-10-25 00:00:00.000";
	private static final Logger logger = LoggerFactory.getLogger(QueueSender.class);
	public String tableName = "clubitem";

	/**
	 * This functions is scheduled for every 5 mins. It retrives the messages from
	 * the IDAA within the time interval and sends it to service bus.
	 * 
	 * @param maxMessagesForConnection
	 */
//	@Scheduled(cron = " 0 0/1 * * * ?")
	public void fetchItemsAndSendMessages(int maxMessagesForConnection, int startItemRange, int ttl) {

		String currentDate = java.time.LocalDate.now().toString();
		String currentTime = java.time.LocalTime.now().toString();
		logger.info("previousTimestamp 1:" + previousTimestamp);
		Date d = parseDate(previousTimestamp);
		logger.info("previousTimestamp 2:" + d.toString());
		Timestamp sysStartTm = new Timestamp(d.getTime());
		logger.debug("service class:sysStartTm used for retrieving latest records=" + sysStartTm);
		previousTimestamp = currentDate + " " + currentTime;

		// Get all the records in between the item Ranges
		List<Object> clubItemList = queueProducerRepository.findByItemRange(startItemRange);
		// This is used both for thread pool size and max connections.

		final int numberOfConnectionsForServiceBus = clubItemList.size() / maxMessagesForConnection;

		logger.debug("Records retrieved from db2:" + clubItemList.size());
		queueSender.setDurationToLive(ttl);
		try {
			queueConnectionProperties.createConnections(numberOfConnectionsForServiceBus);

			groupAndSendMessages(maxMessagesForConnection, clubItemList, numberOfConnectionsForServiceBus);
		} catch (ServiceBusException | InterruptedException | ExecutionException e) {
			logger.debug("Throwed Exception at fetchItemsAndSendMessages() ");
			e.printStackTrace();
		} finally {
			/*
			 * Closing all the connections to the message senders
			 */
			try {
				queueConnectionProperties.closeConnectionsAsync();
			} catch (InterruptedException | ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public Date parseDate(String date) {
		try {
			return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(date);
		} catch (ParseException e) {
			logger.error(
					"exception caught parsing date, date parsed:" + date + "\n Ec=xception details:" + e.getMessage());
			return null;
		}
	}

	/**
	 * We're grouping every n {maxMessagesForConnection} messages and creating a new
	 * connection and sending it to azure service bus.
	 * 
	 * @param maxMessagesForConnection
	 * @param clubItemList
	 * @throws ServiceBusException
	 */
	public void groupAndSendMessages(int maxMessagesForConnection, List<Object> clubItemList,
			int maxConnectionsToServiceBus) {
		List<QueueStats> queueStatsList = new ArrayList<>();
		List<CompletableFuture<Void>> tasks = new ArrayList<>();
		/**
		 * Pool size will be same as of number of connections. This is because we divide
		 * the messages in to equal number of batches and send the batch single
		 * connection. If the number of batches are more than connections we have we
		 * will have overflow.
		 */
		ExecutorService serviceBusExecuterService = Executors.newFixedThreadPool(maxConnectionsToServiceBus);

		try {

			for (int i = 0; i < clubItemList.size(); i += maxMessagesForConnection) {

				int startRange = i;

				int endRange = (clubItemList.size() < i + maxMessagesForConnection) ? clubItemList.size()
						: (i + maxMessagesForConnection);

				QueueStats queueStats = new QueueStats();
				queueStats.setQueueNumber(i / maxMessagesForConnection);
				queueStats.setTotalCount(endRange - i);
				queueStatsList.add(queueStats);

				CompletableFuture<Void> batchMessgaes = CompletableFuture.supplyAsync(() -> {

					// Get the connection which is free. This will the one which is released by
					// previous thread.
					int freeMessageSenderConnectionIndex = 0;
					try {
						freeMessageSenderConnectionIndex = queueConnectionProperties
								.getFreeMessageSenderConnectionIndex();

					} catch (Exception e) {
						logger.debug("Exception in getting free index");
						e.printStackTrace();

						freeMessageSenderConnectionIndex = queueConnectionProperties
								.getFreeMessageSenderConnectionIndex();

					}

					IMessageSender sender = queueConnectionProperties
							.getMessageSender(freeMessageSenderConnectionIndex);

					logger.debug("Sending on connection: " + freeMessageSenderConnectionIndex + "for range: "
							+ startRange + " to " + endRange);

					try {
						queueSender.sendMessages(sender, clubItemList.subList(startRange, endRange), tableName,
								queueStats);
					} catch (JsonProcessingException | InterruptedException | ExecutionException e) {
						logger.error("Failed: groupAndSendMessages() inside sub-thread" + queueStats.getQueueNumber());
					}
					// Release the current connection in use so that other threads in queue
					// can use.
					queueConnectionProperties.freeMessageSenderConnection(freeMessageSenderConnectionIndex);

					return queueStats.getQueueNumber();
				}, serviceBusExecuterService).thenAcceptAsync(s -> {
				});
				tasks.add(batchMessgaes);
			}

			// Wait till all the messages are being sent or logged in case of failure.
			logger.debug("Sending messages started");
			CompletableFuture.allOf(tasks.toArray(new CompletableFuture<?>[tasks.size()])).thenAcceptAsync(s -> {
			}).get();
			logger.debug("Sending messages finished");

			/**
			 * Need to retry messages here. Recursive call to the same method will do the
			 * job.
			 */
		} catch (Exception e) {
			e.printStackTrace();
			logger.debug("FAILED: groupAndSendMessages()" + e.getMessage());

		} finally {
			serviceBusExecuterService.shutdown();
			// logging each connection success and failure stats.
			logQueueStats(queueStatsList, clubItemList.size(), maxMessagesForConnection);
		}

	}

	public void logQueueStats(List<QueueStats> queueStatsList, int totalMessagesSize, int batchSize) {
		int allQueuesSuccessCount = 0;
		int allQueuesFailedCount = 0;
		for (QueueStats queueStats : queueStatsList) {
			queueStats.printQueueStats();
			allQueuesSuccessCount += queueStats.getSuccessCount();
			allQueuesFailedCount += queueStats.getFailedCount();
		}
		logger.debug("Messages batch size: " + batchSize);
		logger.debug("Total Messages: " + totalMessagesSize);
		logger.debug("Sucess: " + allQueuesSuccessCount + "\t Failed: " + (totalMessagesSize - allQueuesSuccessCount));
		logger.debug("Failed list size" + allQueuesFailedCount);
		logger.debug("Success Rate: " + ((allQueuesSuccessCount * 100.00) / totalMessagesSize) + "%");
		for (QueueStats queueStats : queueStatsList) {
			queueStats.printFailedIndex();
		}
	}

}