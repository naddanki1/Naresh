package com.sams.pricing.ppf.thead;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Component;

@Component
public class ThreadHandler {
	final int theadPoolSize = 10;
	ExecutorService serviceBusExecuterService = Executors.newFixedThreadPool(theadPoolSize);

}
