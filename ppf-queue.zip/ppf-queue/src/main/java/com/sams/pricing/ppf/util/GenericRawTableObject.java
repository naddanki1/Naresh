package com.sams.pricing.ppf.util;

public class GenericRawTableObject {
	
	String tableName;
	
	Object jsonObject;
	
	public GenericRawTableObject()
	{
		
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName.toUpperCase();
	}

	public Object getJsonObject() {
		return jsonObject;
	}

	public void setJsonObject(Object jsonObject) {
		this.jsonObject = jsonObject;
	}

}