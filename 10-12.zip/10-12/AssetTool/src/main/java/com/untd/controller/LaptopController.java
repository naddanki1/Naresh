package com.untd.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.untd.template.UserJDBCTemplate;
@Controller
public class LaptopController {
	ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

	 @RequestMapping(value="/laptopAll")
     public String getLaptopDetails (ModelMap model , HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println("Logged in Successuflly");
	    	ArrayList laptops =  userJDBCTemplate.listLaptopAll();
     		model.addAttribute("message", laptops);
         	return "laptop";	
         }
	    else {
		  System.out.println("you are not logged in");  
		  return "redirect:/api/home";
        }
    }
	 
	 
	 @RequestMapping(value="/laptopAdd", produces = "application/json", params = {"id","model", "hostname", "vendor", "sno", "proc_type", "hdd", "ram", "os","os_key", "pdate", "warranty", "edate", "stat", "bond", "uid1", "uid2",  "ea" })
	 public @ResponseBody ()  	
	 String addUser(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "hostname") String hostname,@RequestParam(value = "vendor") String vendor,
	 @RequestParam (value = "sno") String sno,  @RequestParam(value = "proc_type") String proc_type, @RequestParam(value = "hdd") String hdd, @RequestParam (value = "ram") String ram,  
	 @RequestParam(value = "os") String os, 	 @RequestParam (value = "os_key") String os_key,  @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
	 @RequestParam (value = "edate") String edate,  @RequestParam(value = "stat") String stat, @RequestParam(value = "bond") String bond, 	 @RequestParam (value = "uid1") String uid1, 
	 @RequestParam(value = "uid2") String uid2,   @RequestParam(value = "ea") String ea,HttpSession session) throws Exception{
	      
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){
		       String response = userJDBCTemplate.addLaptop(id,model, hostname, vendor, sno, proc_type, hdd, ram, os,os_key, pdate, warranty, edate, stat, bond, uid1,uid2, ea);
		       System.out.println(response);    
		       return response; 
         }
		 else{
			 System.out.println("you are not logged in");
			 return "noSessionId";
		 }
     }
	 
	 @RequestMapping(value="/laptopOnCall")
     public String getLaptopOncallDetails (ModelMap model , HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	String mode = "On-call";
	    	ArrayList laptops =  userJDBCTemplate.getLaptop(mode);
     		model.addAttribute("message", laptops);
         	return "laptopOnCall";	
    }
	 else {
		 System.out.println("you are not logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 @RequestMapping(value="/laptopStore")
     public String getLaptopStoreDetails (ModelMap model , HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	String mode = "Stores";
	    	ArrayList laptops =  userJDBCTemplate.getLaptop(mode);
     		model.addAttribute("message", laptops);
         	return "laptopStores";	
    }
	 else {
		 System.out.println("you are not logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 @RequestMapping(value="/laptopUpdate")
	 public String getLaptopUpdateDetails (ModelMap model, HttpSession session) {
		    String loginAttribute = (String) session.getAttribute("login");
		    if (loginAttribute == "success"){
	 	    System.out.println("getting laptop details");
	 	    ArrayList laptops =  userJDBCTemplate.listLaptopAll();
 		    model.addAttribute("message", laptops);
	          	return "laptopUpdateHome";	
		    }
		    else{
		    	 System.out.println("you are not logged in");
		   		 return "redirect:/api/home";
		   		              
		   	}
	  }
	 
	 @RequestMapping(value="/getLaptopDetails")
		public String getLaptop (@RequestParam int  id,ModelMap model,HttpSession session) {
			String loginAttribute = (String) session.getAttribute("login");
			if (loginAttribute == "success"){
			System.out.println("Id is "+ id);
			ArrayList laptops =  userJDBCTemplate.getLaptopByID(id );
		     		model.addAttribute("message", laptops);
		     		System.out.println(laptops);
		         	return "laptopByID";	
		    }
			else {
					System.out.println("you are not logged in");
					return "redirect:/api/home";
			}
		}
	 @RequestMapping(value="/laptopUpdateFinal",produces = "application/json", params = {"id","model", "hostname", "vendor", "sno", "proc_type", "hdd", "ram", "os","os_key", "pdate", "warranty", "edate", "stat", "bond", "uid1", "uid2", "ea" })
	 public @ResponseBody ()  	
	 String updateCPU(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "hostname") String hostname,@RequestParam(value = "vendor") String vendor,
	 @RequestParam (value = "sno") String sno,  @RequestParam(value = "proc_type") String proc_type, @RequestParam(value = "hdd") String hdd,
	 @RequestParam (value = "ram") String ram,  @RequestParam(value = "os") String os,	 @RequestParam (value = "os_key") String os_key,  
	 @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty, 	 @RequestParam (value = "edate") String edate,  @RequestParam(value = "stat") String stat, @RequestParam(value = "bond") String bond,
	 @RequestParam (value = "uid1") String uid1,  @RequestParam(value = "uid2") String uid2, 
	 @RequestParam(value = "ea") String ea,HttpSession session) throws Exception{
		 
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
		System.out.println("Updating Laptop details");
	 	
	 	String res =  userJDBCTemplate.updateLaptop(id,model, hostname, vendor, sno, proc_type, hdd, ram, os,os_key, pdate, warranty, edate, stat, bond, uid1,uid2, ea);
	    System.out.println(res);
	    return res;	
	    }
		else{
			 System.out.println("you are not logged in");
			 return "noSessionId";
		 }
		
	 }
}
