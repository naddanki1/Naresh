package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller


public class UserController {
	ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");


@RequestMapping(value="/userDetails")
public String getUserDetails (ModelMap model , HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
    
	ArrayList users =  userJDBCTemplate.listUsers();
     		model.addAttribute("message", users);
         	return "users";	
    }
	 else {
		System.out.println("you are not logged in");
		return "redirect:/api/home";
		              
	}
}

@RequestMapping(value="/userUpdate")
public String getUpdateUserDetails (ModelMap model,HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
		System.out.println("getting user details");
		ArrayList users =  userJDBCTemplate.listUsers();
     	model.addAttribute("message", users);
        return "userUpdateHome";	
    }
	else{
		System.out.println("you are not logged in");
		return "redirect:/api/home";
		}
}



@RequestMapping(value="/home")
public String redirectToHome (ModelMap model){
	System.out.println("redirect to home page");
	
         	return "home";	
}

@RequestMapping(value="/getUserDetails")
public String getUser (@RequestParam String  uid,ModelMap model,HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
	System.out.println("Firstname is "+ uid);
	ArrayList users =  userJDBCTemplate.getUser(uid );
     		model.addAttribute("message", users);
     		System.out.println(users);
         	return "userByUID";	
    }
	else {
			System.out.println("you are not logged in");
			return "redirect:/api/home";
	}
}
	

@RequestMapping(value="/userUpdateFinal",produces = "application/json", params = {"id","fname","lname","uid"})
public @ResponseBody () 
 String UpdateUser (@RequestParam (value = "id") int id,  @RequestParam(value = "fname") String fname, @RequestParam(value = "lname") String lname,@RequestParam(value = "uid") String uid,
		 @RequestParam(value = "team") String team, @RequestParam(value = "role") String role , @RequestParam(value = "stat") String stat, @RequestParam(value = "cube") String cube,
		 @RequestParam(value = "jdate") String jdate,@RequestParam(value = "edate") String edate,HttpSession session) throws Exception{
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
	System.out.println("Updating user details");
	String res =  userJDBCTemplate.updateUser(id,fname,lname,uid,team,role,stat,cube,jdate,edate);
     		System.out.println(res);
         	return res;	
    }
	else{
		 return "noSessionId";
	 }
}

 @RequestMapping(value="/userAdd",produces = "application/json", params = {"id","fname","lname","uid","team","role","stat","cube","jdate","edate"})
 public @ResponseBody ()  	
 String addUser(@RequestParam (value = "id") int id,  @RequestParam(value = "fname") String fname, @RequestParam(value = "lname") String lname,@RequestParam(value = "uid") String uid,
		 @RequestParam(value = "team") String team, @RequestParam(value = "role") String role , @RequestParam(value = "stat") String stat, @RequestParam(value = "cube") String cube,
		 @RequestParam(value = "jdate") String jdate,@RequestParam(value = "edate") String edate,HttpSession session) throws Exception{
	 
	 String loginAttribute = (String) session.getAttribute("login");
	 if (loginAttribute == "success"){
	 System.out.println(id + " " +fname);
	 String response = userJDBCTemplate.addUser(id,fname,lname,uid,team,role,stat,cube,jdate,edate);
	 System.out.println(response);    
	 return response; 
     }
	 else{
		 return "noSessionId";
	 }
 }
 
 
 
} 
