package com.untd;

public class Phone {
int id;
String model, vendor, sno,  pdate, warranty, edate, stat, bond, uid1, uid2;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getVendor() {
	return vendor;
}
public void setVendor(String vendor) {
	this.vendor = vendor;
}
public String getSno() {
	return sno;
}
public void setSno(String sno) {
	this.sno = sno;
}

public String getPdate() {
	return pdate;
}
public void setPdate(String pdate) {
	this.pdate = pdate;
}
public String getWarranty() {
	return warranty;
}
public void setWarranty(String warranty) {
	this.warranty = warranty;
}
public String getEdate() {
	return edate;
}
public void setEdate(String edate) {
	this.edate = edate;
}
public String getStat() {
	return stat;
}
public void setStat(String stat) {
	this.stat = stat;
}
public String getBond() {
	return bond;
}
public void setBond(String bond) {
	this.bond = bond;
}
public String getUid1() {
	return uid1;
}
public void setUid1(String uid1) {
	this.uid1 = uid1;
}
public String getUid2() {
	return uid2;
}
public void setUid2(String uid2) {
	this.uid2 = uid2;
}

}
