﻿'use strict';

// optional controllers

   function LoginCheckCtrl ($scope,$http,$window){
	   $http.get('http://localhost:8080/AssetTool/api/checkLogin')
	   .success(function (response) {  
            $scope.value = response; 
                if ($scope.value == "Success") {    
                $window.location.href = 'home';
            }
            else{
            	alert("please login to continue");
            	$window.location.href = "";
            	
            }
	   });
   }
   
	

function LoginCtrl ($scope,$http,$window){
	$scope.SendData = function (Data) {  
        
		
		var userName = Data.userName;  
       var password = Data.password; 
		
		var input = "username=" + userName + "&password=" + password;
		       
		$http.get('http://localhost:8080/AssetTool/api/login?'+input)
		.success(function (response) {  
            $scope.value = response; 
            if ($scope.value == "Success") {    
                $window.location.href = 'home';
            }
            else{
            	alert('invalid credentials');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
  
}

function LogoutCtrl($scope,$http,$window){
		$http.get('http://localhost:8080/AssetTool/api/logout')
			.success(function (response) { 
				$scope.value = response; 
	            if ($scope.value == "Logout") {  
	            	alert("Logged out succesfully");
	                $window.location.href = '';
	            }
	            else if($scope.value == "not loggedin"){
	            	alert("Not logged in");
	            	$window.location.href = '';
	            }
			}).
			error(function (error) {  
	              alert(error);  
	           });
}


function CpuDetailCtrl ($scope,$http,$window){
	        
		$http.get('http://localhost:8080/AssetTool/api/cpuStores')
		.success(function (response) {  
            $scope.html = response; 
             
                     })  
           .error(function (error) {  
              alert(error);  
           });  
    }  



function CpuAddCtrl ($scope,$http,$window){
	
	$scope.SendCPU = function (Data) {  
		
		var id = Data.id;  
		var model = Data.model;  
		var hostname = Data.hostname;  
		var vendor = Data.vendor;  
		var sno = Data.sno;  
		var proc_type = Data.proc_type;  
		var hdd = Data.hdd;  
		var ram = Data.ram; 
		var DIMM = Data.DIMM;  
		var os = Data.os;  
		var os_key = Data.os_key;  
		var pdate = Data.pdate; 
		var warranty = Data.warranty;  
		var edate = Data.edate;  
		var stat = Data.stat;  
		var bond = Data.bond; 
		var uid1 = Data.uid1;  
		var uid2 = Data.uid2;  
		var br = Data.br;  
		var flr = Data.flr;
		var loc = Data.loc;  
		var ea = Data.ea;  
		
		
		var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
		"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram + "&DIMM=" + DIMM + 
		"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
		edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 + "&br=" + br + 
		"&flr=" + flr + "&loc=" + loc + "&ea=" + ea ;
		  
		
		
		$http.get('http://localhost:8080/AssetTool/api/cpuAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
            
            if ($scope.value == "success") {    
            	alert("Cpu Added succesfully")
                $window.location.href = 'cpuDetails';
            }
            
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert("Unable to Add the CPU: Duplicate records found or Invalid input");
            	
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

function CpuUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/cpuUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetCpuByIDCtrl ($scope,$http,$window,$routeParams,$location){
	var id = $routeParams.id;
	
	$http.get('http://localhost:8080/AssetTool/api/getCpuDetails?id='+id)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}

function CpuUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var DIMM = $routeParams.DIMM;  
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var br = $routeParams.br;  
	var flr = $routeParams.flr;
	var loc = $routeParams.loc;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram + "&DIMM=" + DIMM + 
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 + "&br=" + br + 
	"&flr=" + flr + "&loc=" + loc + "&ea=" + ea ;
	  
	  
	   $http.get('http://localhost:8080/AssetTool/api/cpuUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getCpuByID?id='+id;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             else{
            	 
            	 alert('Unable to Update Details: Duplicate records found Or Invalid Input');
            	 $window.location.href = 'getCpuByID?id='+id;
				}
         
	   })             
    .error(function (error) {  
       alert(error);  
    }); 
}

/// User details ///

function UserDetailCtrl ($scope,$http,$window){
	
	     
		$http.get('http://localhost:8080/AssetTool/api/userDetails')
		.success(function (response) {  
			
            $scope.html = response; 
                       
                     })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
// User update //

function UserUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/userUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetUserByUIDCtrl ($scope,$http,$window,$routeParams,$location){
		var uid = $routeParams.uid
		
		$http.get('http://localhost:8080/AssetTool/api/getUserDetails?uid='+uid)
			.success(function (response) {
		        $scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       });  
}

function UserUpdateCtrl ($scope,$http,$window,$routeParams){
	   var id    = $routeParams.id;  
       var fname = $routeParams.fname; 
	   var lname = $routeParams.lname;
	   var uid   = $routeParams.uid;
	   var team  = $routeParams.team;
	   var role  = $routeParams.role;
	   var stat  = $routeParams.stat;
	   var cube  = $routeParams.cube;
	   var jdate = $routeParams.jdate;
	   var edate = $routeParams.edate;
	  
	   var input = "id=" + id + "&fname=" + fname + "&lname=" + lname + "&uid=" + uid + "&team=" + team + "&role=" + role + "&stat=" + stat + "&cube=" + cube + "&jdate=" + jdate+ "&edate=" + edate ;
	  
	   $http.get('http://localhost:8080/AssetTool/api/userUpdateFinal?'+input)
	   .success(function (response) {  
        		$scope.value = response; 
				if ($scope.value == "success") {    
                 	alert("Details Updated succesfully")
                    $window.location.href = 'getUserByUID?uid='+uid;
                }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
                else{
					alert('Duplicate records found Or Invalid input');
				}
            
	   })             
       .error(function (error) {  
          alert(error);  
       }); 
}

function UserAddCtrl ($scope,$http,$window){
	
	$scope.SendUser = function (Data) {  
		
		var id    = Data.id;  
        var fname = Data.fname; 
		var lname = Data.lname;
		var uid   = Data.uid;
		var team  = Data.team;
		var role  = Data.role;
		var stat  = Data.stat;
		var cube  = Data.cube;
		var jdate = Data.jdate;
		var edate = Data.edate;
		
		var input = "id=" + id + "&fname=" + fname + "&lname=" + lname + "&uid=" + uid + "&team=" + team + "&role=" + role + "&stat=" + stat + "&cube=" + cube + "&jdate=" + jdate+ "&edate=" + edate ;
		  
		$http.get('http://localhost:8080/AssetTool/api/userAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("user Added succesfully")
                $window.location.href = 'userDetails';
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert('Unable to update details: Duplicate records found Or Invalid input');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

/// Start of Monitor controllers  ///
function MonitorStoreCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorDesktopCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorDesktop')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorFaultyCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorFaulty')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorOutCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorOut')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorAddCtrl ($scope,$http,$window){
	
	$scope.SendMonitor = function (Data) {  
		
		var id        = Data.id;  
        var model     = Data.model; 
		var vendor    = Data.vendor;
		var sno	      = Data.sno;
		var size  	  = Data.size;
		var color     = Data.color;
		var pdate     = Data.pdate;
		var warranty  = Data.warranty;
		var edate     = Data.edate;
		var stat      = Data.stat;
		var bond      = Data.bond;
		var uid1      = Data.uid1;
		var uid2      = Data.uid2;
		
		var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
		  
		$http.get('http://localhost:8080/AssetTool/api/monitorAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("Monitor Added succesfully")
                $window.location.href = 'monitorAll';
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert('Unable to update details: Duplicate records found Or Invalid input');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

function MonitorUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/monitorUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetMonitorByIDCtrl ($scope,$http,$window,$routeParams,$location){
	var id = $routeParams.id
	
	$http.get('http://localhost:8080/AssetTool/api/getMonitorDetails?id='+id)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function MonitorUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
	  
	  $http.get('http://localhost:8080/AssetTool/api/monitorUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getMonitorByID?id='+id;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             else{
					alert('Unable to update the details: Duplicate records found Or Invalid input');
					$window.location.href = 'getMonitorByID?id='+id;
				}
         
	   })             
    .error(function (error) {  
       alert(error);  
    }); 
}
/// End of Monitor controllers ////

/// Start of Phone controllers ////
function PhoneStoreCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneDesktopCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneDesktop')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneFaultyCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneFaulty')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneOutCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneOut')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneAddCtrl ($scope,$http,$window){
	
	$scope.SendPhone = function (Data) {  
		
		var id        = Data.id;  
        var model     = Data.model; 
		var vendor    = Data.vendor;
		var sno	      = Data.sno;
		var pdate     = Data.pdate;
		var warranty  = Data.warranty;
		var edate     = Data.edate;
		var stat      = Data.stat;
		var bond      = Data.bond;
		var uid1      = Data.uid1;
		var uid2      = Data.uid2;
		
		var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno +  "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
		  
		$http.get('http://localhost:8080/AssetTool/api/phoneAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("Phone details Added succesfully")
                $window.location.href = 'phoneAll';
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert('Unable to update details: Duplicate records found Or Invalid input');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

function PhoneUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/phoneUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetPhoneByIDCtrl ($scope,$http,$window,$routeParams,$location){
	var id = $routeParams.id
	
	$http.get('http://localhost:8080/AssetTool/api/getPhoneDetails?id='+id)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function PhoneUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
	  
	  $http.get('http://localhost:8080/AssetTool/api/phoneUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getPhoneByID?id='+id;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             else{
					alert('Unable to update the details: Duplicate records found Or Invalid input');
					$window.location.href = 'getPhoneByID?id='+id;
				}
         
	   })             
    .error(function (error) {  
       alert(error);  
    }); 
}


/// End of Phone controllers ///

//// Start of Laptop controllers  ////
function LaptopAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
} 


function LaptopAddCtrl ($scope,$http,$window){
	
	$scope.SendLaptop = function (Data) {  
		
		var id = Data.id;  
		var model = Data.model;  
		var hostname = Data.hostname;  
		var vendor = Data.vendor;  
		var sno = Data.sno;  
		var proc_type = Data.proc_type;  
		var hdd = Data.hdd;  
		var ram = Data.ram; 
		var os = Data.os;  
		var os_key = Data.os_key;  
		var pdate = Data.pdate; 
		var warranty = Data.warranty;  
		var edate = Data.edate;  
		var stat = Data.stat;  
		var bond = Data.bond; 
		var uid1 = Data.uid1;  
		var uid2 = Data.uid2;  
		var ea = Data.ea;  
		
		
		var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
		"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram + "&os=" + os + 
		"&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
		edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 + "&ea=" + ea ;
		  
		
		
		$http.get('http://localhost:8080/AssetTool/api/laptopAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
            
            if ($scope.value == "success") {    
            	alert("Laptop Details Added succesfully")
                $window.location.href = 'laptopAll';
            }
            
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert("Unable to Add the Laptop: Duplicate records found or Invalid input");
            	
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

function LaptopOnCallCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopOnCall')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  


function LaptopStoresCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function LaptopUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/laptopUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetLaptopByIDCtrl ($scope,$http,$window,$routeParams,$location){
	var id = $routeParams.id
	
	$http.get('http://localhost:8080/AssetTool/api/getLaptopDetails?id='+id)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function LaptopUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram +  
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 +  "&ea=" + ea ;
	  
	  
	   $http.get('http://localhost:8080/AssetTool/api/laptopUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getLaptopByID?id='+id;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             else{
            	 
            	 alert('Unable to Update Details: Duplicate records found Or Invalid Input');
            	 $window.location.href = 'getLaptopByID?id='+id;
				}
         
	   })             
    .error(function (error) {  
       alert(error);  
    }); 
}

function HomeCtrl($scope, $http) {
}

function ProjectCtrl($scope, $http) {
}

function PrivacyCtrl($scope, $http, $timeout) {
}

function AboutCtrl($scope, $http, $timeout) {
}
