package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class PhoneMapper implements RowMapper {
   public Phone mapRow(ResultSet rs, int rowNum) throws SQLException {
      Phone phone = new Phone();
      phone.setId(rs.getInt("id"));
      phone.setModel(rs.getString("model"));
      phone.setVendor(rs.getString("vendor"));
      phone.setSno(rs.getString("sno"));
      phone.setPdate(rs.getString("pdate"));
      phone.setWarranty(rs.getString("warranty"));
      phone.setEdate(rs.getString("edate"));
      phone.setStat(rs.getString("stat"));
      phone.setBond(rs.getString("bond"));
      phone.setUid1(rs.getString("uid1"));
      phone.setUid2(rs.getString("uid2"));
          
      return phone;
   }
}