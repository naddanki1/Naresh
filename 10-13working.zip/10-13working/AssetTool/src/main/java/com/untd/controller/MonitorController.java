package com.untd.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.untd.template.UserJDBCTemplate;

@Controller
public class MonitorController {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	UserJDBCTemplate userJDBCTemplate = (UserJDBCTemplate)context.getBean("userJDBCTemplate");
	 
	@RequestMapping(value = "/monitorAll")
	public String getMonitorAll(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("getting monitoring details");
			String mode = "*";
			
			ArrayList monitors =  userJDBCTemplate.listMonitorAll();
     		model.addAttribute("message", monitors);
         	return "monitorAll";	        }
	   else {
	 	    System.out.println("Failed to get monitor details : User not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/monitorAdd",produces = "application/json", params = {"id","model","vendor","sno","size","color","pdate","warranty","edate","stat","bond","uid1","uid2"})
	 public @ResponseBody ()  	
	 String addMonitor(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "size") String size, @RequestParam(value = "color") String color , @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
             @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat, @RequestParam(value = "bond") String bond ,
			 @RequestParam(value = "uid1") String uid1, @RequestParam(value = "uid2") String uid2, HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){
		 System.out.println("Adding monitor details");
		 String response = userJDBCTemplate.addMonitor(id,model,vendor,sno,size,color,pdate,warranty,edate,stat,bond,uid1,uid2);
		 System.out.println(response);    
		 return response; 
	     }
		 else{
			 System.out.println("Failed to add monitor details: User not logged in");
			 return "noSessionId";
		 }
	 }
	
	@RequestMapping(value="/monitorUpdate")
	public String getUpdateUserDetails (ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("Getting monitor details to update  ");
			ArrayList monitors =  userJDBCTemplate.listMonitorAll();
	     	model.addAttribute("message", monitors);
	        return "monitorUpdateHome";	
	    }
		else{
			System.out.println("Failed to  the monitor details: User not logged in");
			return "redirect:/api/home";
			}
	}
	
	@RequestMapping(value="/monitorUpdateFinal",produces = "application/json",params = {"id","model","vendor","sno","size","color","pdate","warranty","edate","stat","bond","uid1","uid2"})
	 public @ResponseBody ()  	
	 String updateMonitor(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "size") String size, @RequestParam(value = "color") String color , @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
            @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat, @RequestParam(value = "bond") String bond ,
			 @RequestParam(value = "uid1") String uid1, @RequestParam(value = "uid2") String uid2, HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){
			 System.out.println("Updating monitor details");
		     String res =  userJDBCTemplate.updateMonitor(id,model,vendor,sno,size,color,pdate,warranty,edate,stat,bond,uid1,uid2);
	     	 return res;	
	    }
		else{
			System.out.println("Failed to Update monitor details: User not logged in"); 
			 return "noSessionId";
		 }
	}
	@RequestMapping(value = "/monitorStore")
	public String getMonitorStore(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("Getting monitor store details");
			String mode = "Stores";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorStores";	
        }
	   else {
	 	    System.out.println("Failed to get the monitor store details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/monitorDesktop")
	public String getMonitorDesktop(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("Getting monitor desktop details");
			String mode = "Desktop";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorDesktop";	
        }
	   else {
		    System.out.println("Failed to get the monitor desktop details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/monitorFaulty")
	public String getMonitorFaulty(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("Getting monitor faulty details");
			String mode = "Faulty";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorFaulty";	
        }
	   else {
		   System.out.println("Failed to get the monitor faulty details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value = "/monitorOut")
	public String getMonitorOut(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			System.out.println("Getting monitor out details");
			String mode = "Out";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorOut";	
        }
	   else {
		   System.out.println("Failed to get the monitor out details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/getMonitorDetails")
	public String getUser (@RequestParam String  id,ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
		System.out.println("Getting monitor details by Id:  "+ id);
		ArrayList monitors =  userJDBCTemplate.getMonitor(id );
	     		model.addAttribute("message", monitors);
	     		System.out.println(monitors);
	         	return "monitorByID";	
	    }
		else {
			System.out.println("Failed to get the monitor details by id : User  not logged in");
				return "redirect:/api/home";
		}
	}
	
}
	


