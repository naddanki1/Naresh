import React from 'react';
import { connect } from 'react-redux';
import { change } from '../_actions/createProjectPageActions';
import {browserHistory} from 'react-router-dom';
import {findDOMNode} from 'react-dom'
import ReactTooltip from 'react-tooltip'


class CreateProjectPage extends React.Component{

 constructor(props){
    super(props);
    this.projectName="";
    this.email="";
    this.description="";
    this.submitted=false;
    this.onChangeAction = this.onChangeAction.bind(this);
    this.handleRedirect  = this.handleRedirect.bind(this);
    this.handleToolTip = this.handleToolTip.bind(this);
    this.unhandleToolTip = this.unhandleToolTip.bind(this);
    
}


componentDidMount(){
   this.projectName=this.props.projectName;
   this.description=this.props.description;
   this.email=this.props.email;
   
}


onChangeAction(e){
    e.preventDefault();
    
    if(e.target.name=="projectName"){
       this.projectName = e.target.value;
    }
    else if(e.target.name=="email"){
       this.email= e.target.value;
    }
    else if (e.target.name=="description"){
        this.description=e.target.value;
    }
    else if (e.target.name =="submitted"){
        this.submitted=e.target.value;
        
    }
    else if (e.target.name=="clearBtn"){
       this.projectName = ""
       this.email =""
       this.description=""
       this.submitted=false
    }

    
    this.props.onChange(this.projectName,this.description,this.email,this.submitted);
}

handleRedirect(e){
             e.preventDefault();
             const btnName = e.target.name;
             if(btnName == "cancelBtn"){
                this.props.history.push("/");
             }
             else if(btnName == "nextBtn"){
                if(/walmart.com|wal-mart.com|walmartlabs.com/.test(this.email)){
                    this.props.history.push("/createCabinet");
                }                
                }
            else{
                alert("Email should be of one of the these domains @walmart.com or @wal-mart.com or @walmartlabs.com ");
                this.props.history.push("/createProject");
                }
             }
        
 
 
 handleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            if(toolTipName == "projectToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "descriptionToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.descriptionToolTip));
            }
            else if(toolTipName == "emailToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.emailToolTip));
            }
  }

  unhandleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            if(toolTipName == "projectToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "descriptionToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.descriptionToolTip));
            }
            else if(toolTipName == "emailToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.emailToolTip));
            }
 }



render(){
   
        return(<div >

        <h2 className={"col-md-4 col-md-offset-5"}>Create Project</h2>
        <br/><br/>
        <ReactTooltip />
          
        <form name="form" className={"col-md-4 col-md-offset-4"} >
        
        <div className={'row' }>
               <label htmlFor = "projectName">Project Name   </label><br/>
               <div class="col-xs-10">
               <input type="text"   className="form-control" name="projectName" value={this.props.projectName}  onChange={this.onChangeAction} /> &nbsp;
               </div>
               <div >
               <input type="image"  name="projectToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
               </div>
               <br/>
               
               <p ref='projectToolTip' data-tip='Project Name should be like this'></p>
                {this.props.submitted && !this.props.projectName &&
                                            <div className="help-block">Project Name is required</div>
                                        }
         </div> 
               
        
        <div className={'row'}>
                <div>
                <label htmlFor="description" >Description  </label><br/>
                </div>
                <div class="col-xs-10">
                <input type="text" className="form-control" name="description" value={this.props.description}  onChange={this.onChangeAction}/> &nbsp;
                </div>
                <div >
                <input type="image" name="descriptionToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>
                </div>
                <p ref='descriptionToolTip' data-tip='Description should be like this'></p>
                 {this.props.submitted && !this.props.description &&
                                            <div className="help-block">Description is required</div>
                                        }
         </div>
        
        <div className={'row'}>
                <label htmlFor="email">Email Id </label><br/>
                <div class="col-xs-10">
                <input type="email"  className="form-control" name="email" value={this.props.email}  onChange={this.onChangeAction} /> &nbsp;
                </div>
                <div >
                <input type="image"  name="emailToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='emailToolTip' data-tip='email should be like this'></p> 
                 {this.props.submitted && !this.props.email &&
                                            <div className="help-block">Email is required</div>
                                        }
         </div>

        <div>
           <button className="btn btn-primary" name="clearBtn" onClick={this.onChangeAction}>Clear</button> <span/>
           <button className="btn btn-primary" name="cancelBtn" onClick={this.handleRedirect}> Cancel </button> <span/>
           {( !this.props.projectName || !this.props.description || !this.props.email) && <button className="btn btn-primary" name="nextBtn" onClick={this.handleRedirect} disabled> Next </button>}
           {this.props.projectName && this.props.description && this.props.email && <button className="btn btn-primary" name="nextBtn" onClick={this.handleRedirect} > Next </button>}
            

        </div>

     </form>
           
     </div>);
    }


}

const mapStateToProps = (state,props) => {
   
   
    return {
        projectName: state.project.projectName,
        description: state.project.description,
        email: state.project.email,
        submitted:state.project.submitted
    }
};

const mapActionsToProps =  {
         onChange : change,
         
};

export default connect(mapStateToProps, mapActionsToProps ) (CreateProjectPage);