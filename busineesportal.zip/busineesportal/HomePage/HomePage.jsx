import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link  } from 'react-router-dom'
import CreateProjectPage  from '../CreateProjectPage/CreateProjectPage.jsx';
import CreateCabinetPage  from '../createCabinetPage/CreateCabinetPage.jsx';
import CreateFolderPage  from '../createFolderPage/CreateFolderPage.jsx';
import CreateObjectTypePage  from '../createObjectTypePage/CreateObjectTypePage.jsx';
import UpdateProjectPage from '../UpdateProjectPage/UpdateProjectPage.jsx';
import FaqPage from '../FaqPage/FaqPage.jsx';
import ContactUsPage from '../ContactUsPage/ContactUsPage.jsx';


class HomePage extends React.Component {

      
   render() {
      return (
         <Router>
            <div >
        
	           <ul class="nav nav-pills nav-justified">
                  
                  <li><Link to={'/createProject'}>Create Project </Link></li>
                  <li><Link to={'/updateProject'}> Update Project </Link></li> 
                  <li><Link to={'/faq'}> FAQs </Link></li> 
                  <li><Link to={'/contactUs'}> Contact Us </Link></li> 
                  
               </ul>


               <Switch>
                 
                  <Route   path='/createProject' component={CreateProjectPage} />
                  <Route   path='/createCabinet' component={CreateCabinetPage} />
                  <Route   path='/createFolder' component={CreateFolderPage} />
                  <Route   path='/createObjectType' component={CreateObjectTypePage} />
                  <Route   path='/updateProject' component={UpdateProjectPage} />
                  <Route   path='/faq' component={FaqPage} />  
                  <Route   path='/contactUs' component={ContactUsPage} />

               </Switch>
            </div>
         </Router>
         );
   }
}
export default HomePage;