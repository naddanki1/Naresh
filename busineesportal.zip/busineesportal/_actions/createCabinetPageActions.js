
import $ from 'jquery';
export const ACTION_CHANGE = 'cabinet:change';

export function change(PROJECT_NAME,CABINET_NAME,EMAIL,SUBMITTED) {
    
    
    return{
        type: ACTION_CHANGE,
        payload: {
             cabinet: {projectName:PROJECT_NAME,cabinetName:CABINET_NAME,email:EMAIL,submitted:SUBMITTED}
                 
        }

    };
}
