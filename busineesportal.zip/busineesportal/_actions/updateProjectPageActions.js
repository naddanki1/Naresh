import $ from 'jquery';
export const ACTION_CHANGE = 'updateProject:change';

export function change(PROJECT_NAME,DESCRIPTION,CABINET_NAME,FOLDER_TAXONOMY,EMAIL,IS_ADD_CABINET,IS_ADD_FOLDER,ADD_CABINET,ADD_FOLDER) {
    
    return{
        type: ACTION_CHANGE,
        payload: {
             updateProject: {projectName:PROJECT_NAME,description:DESCRIPTION,cabinetName:CABINET_NAME,folderTaxonomy:FOLDER_TAXONOMY,email:EMAIL,isAddCabinet:IS_ADD_CABINET,isAddFolder:IS_ADD_FOLDER,addCabinet:ADD_CABINET,addFolder:ADD_FOLDER}
         }
    };
}

export function apiRequest(prop1,prop2,prop3,prop4,prop5,prop6) {
    console.log("Apir args are "+ prop1,prop2,prop3,prop4,prop5,prop6);
return dispatch => {
var getUrl;
 getUrl=   $.ajax({
        type: 'GET',
        crossDomain: true,
        headers:{"Access-Control-Expose-Headers": "Access-Control-Allow-Origin,Access-Control-Allow-Credentials"},
        url: 'http://dctm-mobile-rest.prod.walmart.com:8080/DctmRest/repositories',
        success(response){
                console.log('Success');

                response.setHeader({"Access-Control-Allow-Origin" : "http://localhost:7788"})
                console.log(response);
            },
            
            error(){
                console.log('Error');
                
                }
        });
    }


}

