import $ from 'jquery';
export const ACTION_CHANGE = 'project:change';


export function change(PROJECT_NAME,DESCRIPTION,EMAIL,SUBMITTED) {
    return{
        type: ACTION_CHANGE,
        payload: {
            project: {projectName:PROJECT_NAME,description:DESCRIPTION,email:EMAIL,submitted:SUBMITTED}
        }
    };
}

export function apiRequest() {
return dispatch => {
var getUrl;
 getUrl=   $.ajax({
        type: 'GET',
        crossDomain: true,
        headers:{'Content-Type': 'application/x-www-form-urlencoded'},
        // headers:{"Access-Control-Expose-Headers": "Access-Control-Allow-Origin,Access-Control-Allow-Credentials","Access-Control-Allow-Methods": "GET, POST, PUT, DELETE"},
        //url: 'http://localhost:8080/DCTM/repositories',
       
        url: 'http://dctm-mobile-rest.prod.walmart.com:8080/DctmRest/repositories',
        success(response){
                console.log('Success');
                console.log(response);
            },
            
        error(){
                console.log('Error');
                
            }
        });
    }


}

