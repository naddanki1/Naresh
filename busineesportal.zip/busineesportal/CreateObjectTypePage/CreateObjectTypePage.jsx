import React from 'react';
import PopUp from "reactjs-popup";
import { connect } from 'react-redux';
import { change,apiRequest } from '../_actions/createObjectTypePageActions';
import {browserHistory} from 'react-router-dom';
import {findDOMNode} from 'react-dom'
import ReactTooltip from 'react-tooltip'
import ReactTable from 'react-table'

class CreateObjectTypePage extends React.Component {
    constructor(props) {
       super(props);
       this.attributes=[],
       this.projectName="",
       this.cabinetName="",
       this.objectType="",
       this.submitted= false,
       this.addAttribute= false,
       this.attributeName= "",
       this.attributeType= "",
       this.attributeSize= '',
       this.attributeIsRepeated= '',
       this.handleHeader=false,
   
       this.onChangeAction = this.onChangeAction.bind(this);
       this.handleToolTip = this.handleToolTip.bind(this);
       this.unhandleToolTip = this.unhandleToolTip.bind(this);
       this.handleSubmit = this.handleSubmit.bind(this);
       this.handleRedirect  = this.handleRedirect.bind(this);
       this.handlePop = this.handlePop.bind(this);
       this.handleAttributeChange = this.handleAttributeChange.bind(this); 
       this.handleAddAttributeChange = this.handleAddAttributeChange.bind(this);
       this.handleClearAttribute = this.handleClearAttribute.bind(this);
       this.handleRemoveAttribute = this.handleRemoveAttribute.bind(this);
       this.onApiRequestAction = this.onApiRequestAction.bind(this);
   };

   componentDidMount(){
   this.projectName = this.props.projectName;
   this.cabinetName = this.props.cabinetName;
   
   this.objectType = this.props.objectType;
   }
    
   onApiRequestAction(){
    this.props.onApiRequest();
   }
   onChangeAction(e){
        e.preventDefault();
        
        if(e.target.name=="projectName"){
            this.projectName = e.target.value;
        }
        else if(e.target.name=="objectType"){
            this.objectType= e.target.value;
        }
        else if(e.target.name=="addAttribute"){
                    
            {this.attributes.push({ name: this.attributeName,type: this.attributeType, size: this.attributeSize, isRepeated: this.attributeIsRepeated })};
             const newAttributes = this.attributes.map((attribute, sidx) => {
             return attribute;
             });

             this.attributes= newAttributes;
             
        }

        else if (e.target.name=="clearBtn"){
            this.projectName="";
            this.objectType="";
            this.attributes=[];
        }

        this.props.onChange(this.projectName,this.objectType,this.attributes);
     
    }

  handleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            
            if(toolTipName == "projectToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "objectToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.objectToolTip));
            }
            
   }

  unhandleToolTip(e){
            e.preventDefault();
            const toolTipName = e.target.name;
            
            if(toolTipName == "projectToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "objectToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.objectToolTip));
            }
            
   }

     
    
    handleRedirect(e){
       e.preventDefault();
       const btnName = e.target.name;
       if(btnName == "cancelBtn"){
           this.props.history.push("/");
       }
       
       else if(btnName == "prevBtn"){
           this.props.history.push("/createFolder");
       }

    }
    
    handlePop(e){
        e.preventDefault();
    }
    
    handleSubmit(e) {
       e.preventDefault();
  
       this.submitted=true;
       this.onApiRequestAction();
       console.log(this.projectName, this.objectType,  this.attributes);
       
    }

       
    handleAttributeChange= (idx) => (evt) => {
        console.log("hanlde r "+evt.target.name );
        const newAttributes = this.attributes.map((attribute, sidx) => {
        if (idx !== sidx) return attribute;
        
        if(evt.target.name == "name"){
          return { ...attribute,name : evt.target.value };  
        }
        else if(evt.target.name == "type"){
          return { ...attribute,type : evt.target.value };  
        }
        else if(evt.target.name == "size"){
          return { ...attribute,size : evt.target.value };  
        }
        else if(evt.target.name == "isRepeated"){
            if( attribute.isRepeated=="" ){
             this.isRepeated= "on" ;
             return { ...attribute,isRepeated : "on" };
             }
         
            else{
             this.isRepeated= "" ;
             return { ...attribute,isRepeated : "" }; 
            }
         }


        }); 
        
        this.attributes= newAttributes;
        this.props.onChange(this.projectName,this.objectType,this.attributes);
    }



    handleAddAttributeChange(evt)  {
        const { name, value } = evt.target;
        if(name == "attributeName"){
            this.attributeName = value;
        }       
        else if (name == "attributeSize"){
            this.attributeSize = value;
        }      
        else if (name == "attributeType"){
            this.attributeType = value;
        }      
        else if (name == "attributeIsRepeated"){
            this.attributeIsRepeated = value;
        }  
         
     }                  

    handleClearAttribute(){
         
         this.attributeName="";
         this.attributeType="";
         this.atributeSize="";
         this.attributeIsRepeated="";

    } 
    

    handleRemoveAttribute = (idx) => () => {
        
        this.attributes= this.attributes.filter((s, sidx) => idx !== sidx);
        this.props.onChange(this.projectName,this.objectType,this.attributes);
    } 

    render() {
        
        return(<div >

           <h2 className={"col-md-4 col-md-offset-5"}>Create Object Type </h2>
           <ReactTooltip />
           <form name="form" className={"col-md-4 col-md-offset-4"} >
        
            <div className={'row' }>
                <label htmlFor = "projectName">Project Name   </label><br/>
                <div class="col-xs-10">
                <input type="text"   className="form-control" name="projectName" value={this.props.projectName}  onChange={this.onChangeAction} /> &nbsp;
                </div>
                <div >
                <input type="image"  name="projectToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <br/>
                
                <p ref='projectToolTip' data-tip='Project Name should be like this'></p>
                    
            </div> 
            <div className={'row'} >
                <label htmlFor="objectType">Object Type </label><br/>
                <div class="col-xs-10">
                <input type="text" className="form-control" name="objectType" value={this.props.objectType} onChange={this.onChangeAction} />
                </div> 
                <div >
                <input type="image"  name="objectToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='objectToolTip' data-tip='Object Type should be like this'></p>
                
                <br/>                       
            </div>
 
        <br/>
    <div className={"row"}>
    <label htmlFor = "attributes">Attributes </label>

     {this.props.attributes &&   <table >
                <tr>
                <th className={"col-xs-4 "}>Name</th>
                <th className={"col-xs-4 "}>Type</th>
                <th className={"col-xs-3 "}>Size</th>
                <th>Repeating</th>
                </tr>
            
           { this.props.attributes.map((attribute, idx) => (
            <tr >
            
            <td className={"col-xs-4 "}>
           
            <input  type="text"  name="name" value={attribute.name} className="form-control" onChange={this.handleAttributeChange(idx)} 
                /><span/><span/> 
            </td>
            
            
            <td className={"col-xs-4"}>
                        <input type="text" name="type" className="form-control" value={attribute.type} onChange={this.handleAttributeChange(idx)}/> </td>
            
            
            <td className={"col-xs-3"}>
                        <input  type="number"   name="size" className="form-control" value={attribute.size}  onChange={this.handleAttributeChange(idx)} />
                
            <span/><span/></td>
            
            
            {attribute.isRepeated &&  <td>  <input  type="checkbox"   name="isRepeated"  onChange={this.handleAttributeChange(idx)}  checked
                /><span/><span/>
            </td> }
            {!attribute.isRepeated &&  <td ><input  type="checkbox"   name="isRepeated"  onChange={this.handleAttributeChange(idx)} 
                /><span/><span/>
            </td> }
            <td> <input type="image"  name="cancelBtn" src="../images/cancel.jpg" onClick={this.handleRemoveAttribute(idx)}   /></td>
            </tr> 
            ))} 
            
        </table> }
        </div>
        <br/><br/>
            
    </form>
    
  
 <br/>

<div className={"col-md-4 col-md-offset-4"}>
 <PopUp  trigger={<button > Available Attributes</button> }position="right center">
          <div>
          <h4>Available Attributes</h4> 
                 
          <p>Author, Project, Title</p><br/>
          
          </div>
 </PopUp> 
 <br/><br/>
 </div> 
 
 
 <div className={"col-md-4 col-md-offset-4"}>
 <PopUp   trigger={<button >Add Attribute</button> }position="right center">
          <div>
          <h4>Add Attribute details</h4> 
          <div id="attr" className="attribute">
          <form >
          <tr>
          Name:<input  type="text"   name="attributeName"  onChange={this.handleAddAttributeChange}  /><span/><span/>
          </tr><br/>
          <tr>
          Type:
            <select name="attributeType" onChange={this.handleAddAttributeChange}  >
            <option value="" selected></option>
            <option value="String" >String</option>
            <option value="Numeric">Numeric</option>
            <option value="AlphaNumeric">AlphaNumeric</option>
            </select><span/><span/>
          </tr><br/>
          <tr>
           Size:<input  type="number"  name="attributeSize"  onChange={this.handleAddAttributeChange}        /><span/><span/>
          </tr><br/>
          <tr>
           Is Repeating<input  type="checkbox"   name="attributeIsRepeated"  onChange={this.handleAddAttributeChange}     /><span/><span/>
          </tr><br/>
          <tr>
            <button type="button" name="addAttribute" onClick={this.onChangeAction} >Add</button>
          </tr>
          </form>
          </div>
          </div>
          </PopUp> 
          <br/><br/>
   </div>   

          
          <div className={"col-md-4 col-md-offset-4"} >
          <button className="btn btn-primary" name="prevBtn"  onClick={this.handleRedirect}>Prev</button> <span/>
          <button className="btn btn-primary" name="clearBtn" onClick={this.onChangeAction}>Clear</button> <span/>
          <button className="btn btn-primary" name="submitBtn" onClick={this.handleSubmit}> Submit </button> <span/>
          <button className="btn btn-primary" name="cancelBtn" onClick={this.handleRedirect}> Cancel </button> <span/>

          </div>
          
 


  </div>);
        
 }
 
}

const mapStateToProps = (state,props) => {
  
    return {
        projectName: state.project.projectName,
        cabinetName: state.cabinet.cabinetName,
        objectType: state.object.objectType,
        attributes: state.object.attributes,
        
        }
};

const mapActionsToProps =  {
         onChange : change,
         onApiRequest: apiRequest
         
};
export default connect(mapStateToProps, mapActionsToProps ) (CreateObjectTypePage);

