import React from 'react';
import { connect } from 'react-redux';
import {browserHistory} from 'react-router-dom';
import {findDOMNode} from 'react-dom';
import ReactTooltip from 'react-tooltip';
import { change, apiRequest } from '../_actions/createFolderPageActions';

class CreateFolderPage extends React.Component {

       constructor(props)
            {
               super(props);
               this.projectName="";
               this.cabinetName="";
               this.tempFolderTaxonomy="";
		       this.folderTaxonomy="";
               this.email= "";
               this.submitted=false;
			   this.maxLevels=5;
               this.onChangeAction = this.onChangeAction.bind(this);
               this.handleRedirect  = this.handleRedirect.bind(this);
               this.handleToolTip = this.handleToolTip.bind(this);
               this.unhandleToolTip = this.unhandleToolTip.bind(this);
               

       };

componentDidMount(){
   
   this.projectName=this.props.projectName;
   this.cabinetName=this.props.cabinetName;
   this.folderTaxonomy=this.props.folderTaxonomy;
   this.email=this.props.email;
     
}

                           
    onChangeAction(e){
    e.preventDefault();
    
    if(e.target.name=="projectName"){
       this.projectName = e.target.value;
    }
    else if(e.target.name=="email"){
       this.email= e.target.value;
    }
    else if (e.target.name=="cabinetName"){
        this.cabinetName=e.target.value;
    }
    else if (e.target.name =="submitted"){
        this.submitted=e.target.value;
    }
    else if (e.target.name =="folderTaxonomy"){
        this.folderTaxonomy=e.target.value;
        var noOfLevels = this.folderTaxonomy.split("/").length -1 ;

	    if(noOfLevels > 5 ){
            this.folderTaxonomy=this.tempFolderTaxonomy;
				alert("no of sub levels should not be more than 5");
        }	
        else{
            this.tempFolderTaxonomy = this.folderTaxonomy;
        }
    }
    else if (e.target.name=="clearBtn"){
       this.projectName = "";
       this.email ="";
       this.cabinetName="";
       this.folderTaxonomy="";
       this.submitted=false;
    }

    //console.log(this.projectName+ " "+ this.cabinetName+" "+this.email +  " "+this.folderTaxonomy+" "+this.submitted );

    this.props.onChange(this.projectName,this.cabinetName,this.folderTaxonomy,this.email,this.submitted);
}

   handleRedirect(e){
       e.preventDefault();
       const btnName = e.target.name;
       if(btnName == "cancelBtn"){
          this.props.history.push("/");
       }
       else if(btnName == "nextBtn"){
          this.props.history.push("/createObjectType");
       }
       else if(btnName == "prevBtn"){
          this.props.history.push("/createCabinet");
       }

    }

   handleToolTip(e){
      e.preventDefault();
      const toolTipName = e.target.name;
      if(toolTipName == "projectToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.projectToolTip));
            }
            else if(toolTipName == "cabinetNameToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.cabinetNameToolTip));
            }
            else if(toolTipName == "folderTaxonomyToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.folderTaxonomyToolTip));
            }
            else if(toolTipName == "emailToolTip"){
                ReactTooltip.show(findDOMNode(this.refs.emailToolTip));
            }
        }
        
   unhandleToolTip(e){
      e.preventDefault();
      const toolTipName = e.target.name;
      if(toolTipName == "projectToolTip"){
          ReactTooltip.hide(findDOMNode(this.refs.projectToolTip));
      }
      else if(toolTipName == "cabinetNameToolTip"){
          ReactTooltip.hide(findDOMNode(this.refs.cabinetNameToolTip));
      }
      else if(toolTipName == "folderTaxonomyToolTip"){
                ReactTooltip.hide(findDOMNode(this.refs.folderTaxonomyToolTip));
            }
      else if(toolTipName == "emailToolTip"){
          ReactTooltip.hide(findDOMNode(this.refs.emailToolTip));
      }
   }
    
   render(){

      return(<div >

      <h2 className={"col-md-4 col-md-offset-5"}>Create Folder </h2>

      <ReactTooltip />
           
      <form name="form" className={"col-md-4 col-md-offset-4"} >
        
        <div className={'row' }>
               <label htmlFor = "projectName">Project Name   </label><br/>
               <div class="col-xs-10">
               <input type="text"   className="form-control" name="projectName" value={this.props.projectName}  onChange={this.onChangeAction} /> &nbsp;
               </div>
               <div>
               <input type="image"  name="projectToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
               </div>
               <p ref='projectToolTip' data-tip='Project Name should be like this'></p>
                {this.props.submitted && !this.props.projectName &&
                                            <div className="help-block">Project Name is required</div>
                                        }
         </div> 
               

        <div className={'row'}>
               <label htmlFor="cabinetName">Cabinet Name </label><br/>
               <div class="col-xs-10">
               <input type="text"  className="form-control" name="cabinetName" value={this.props.cabinetName}  onChange={this.onChangeAction}/> &nbsp;
               </div>
               <div>
               <input type="image" name="cabinetNameToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
               </div>
               <p ref='cabinetNameToolTip' data-tip='Cabinet Name should be like this'></p>
               {this.props.submitted && !this.props.cabinetName &&
                                            <div className="help-block">Cabinet Name is required</div>
                                        }
        </div>

        <div className={'row'}>
                <label htmlFor="folderTaxonomy">Folder Taxonomy </label><br/>
                <div class="col-xs-10">
                <input type="text"  className="form-control" name="folderTaxonomy" value={this.props.folderTaxonomy}  onChange={this.onChangeAction}/> &nbsp;
                </div>
                <div>
                <input type="image" name="folderTaxonomyToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='folderTaxonomyToolTip' data-tip='Folder Taxonomy should be like this'></p>
                 {this.props.submitted && !this.props.folderTaxonomy &&
                                            <div className="help-block">Folder Taxonomy is required</div>
                                        }
        </div>

        <div className={'row'}>
                <label htmlFor="email">Email Id </label><br/>
                <div class="col-xs-10">
                <input type="email"  className="form-control" name="email" value={this.props.email}  onChange={this.onChangeAction} /> &nbsp;
                </div>
                <div>
                <input type="image"  name="emailToolTip" src="../images/tooltip.jpg" onClick={this.handleToolTip} onMouseOver={this.handleToolTip} onFocus={this.handleToolTip} onMouseOut={this.unhandleToolTip} onBlur={this.unhandleToolTip}/>&nbsp;
                </div>
                <p ref='emailToolTip' data-tip='email should be like this'></p> 
                 {this.props.submitted && !this.props.email &&
                                            <div className="help-block">Email is required</div>
                                        }
        </div>

           <div>
           <button className="btn btn-primary" name="prevBtn"  onClick={this.handleRedirect}>Prev</button> <span/>
           <button className="btn btn-primary" name="clearBtn" onClick={this.onChangeAction}>Clear</button> <span/>
           <button className="btn btn-primary" name="cancelBtn" onClick={this.handleRedirect}> Cancel </button> <span/>
           {( !this.props.projectName || !this.props.cabinetName || !this.props.folderTaxonomy || !this.props.email) && <button className="btn btn-primary" name="nextBtn" onClick={this.handleRedirect} disabled> Next </button>} <span/>
           {this.props.projectName && this.props.cabinetName && this.props.folderTaxonomy && this.props.email && <button className="btn btn-primary" name="nextBtn" onClick={this.handleRedirect} > Next </button>} <span/>
       
           </div>

           </form>
           
          </div>);
        }

 }

const mapStateToProps = (state,props) => {
    //console.log("project state  is " +state.project+ " Cabinet state is "+state.cabinet);
   
    return {
        projectName: state.project.projectName,
        cabinetName: state.cabinet.cabinetName,
        folderTaxonomy: state.folder.folderTaxonomy,
        email: state.project.email,
        submitted: state.project.submitted
        
    }
};


const mapActionsToProps =  {
         onChange : change,
         onApiRequest: apiRequest
};
export default connect(mapStateToProps, mapActionsToProps ) (CreateFolderPage);