import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import CreateProjectPage from './CreateProjectPage/CreateProjectPage.jsx';
import HomePage from './HomePage/HomePage.jsx'
import { store } from './_helpers/stores.js';

ReactDOM.render( <Provider store={store}><HomePage/></Provider>,document.getElementById('app'));