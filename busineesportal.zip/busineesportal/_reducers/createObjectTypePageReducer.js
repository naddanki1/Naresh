import {  ACTION_CHANGE } from '../_actions/createObjectTypePageActions';



export default function createObjectTypePageReducer(state = [], action) {
  
  switch (action.type) {
    case ACTION_CHANGE:
      return (action.payload.object);
    default:
      return state;
  }
}

