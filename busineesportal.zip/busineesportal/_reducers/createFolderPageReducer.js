import { ACTION_CLEAR, ACTION_CHANGE } from '../_actions/createFolderPageActions';



export default function createProjectPageReducer(state = {}, action) {
  
  switch (action.type) {
    case ACTION_CLEAR:
      return (action.payload.folder);
    case ACTION_CHANGE:
      return (action.payload.folder);
    default:
      return state;
  }
}

