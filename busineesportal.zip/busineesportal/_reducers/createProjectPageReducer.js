import { ACTION_CHANGE } from '../_actions/createProjectPageActions';



export default function createProjectPageReducer(state = {}, action) {
  
  switch (action.type) {
    case ACTION_CHANGE:
      return (action.payload.project);
    default:
      return state;
  }
}

